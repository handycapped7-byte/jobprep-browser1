# JobPrep Guard: Distraction-Free Whitelist Browser & Study Hub

A specialized, lockdown Android browser and study companion designed specifically for BCS, Bank, and Government job aspirants in Bangladesh. It restricts web access strictly to an curated whitelist of job circulars, official recruitment portals, and national/international news publications, with zero external URL browsing, accompanied by a Pomodoro study timer and daily preparation tracker.

### User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during Phase 1:
> - **Whitelist Enforcement**: Strictly pre-configured whitelist only with no open URL input bar. Any link outside the approved domain list is intercepted and blocked immediately.
> - **Portal Structure**: Categorized dashboard organized by job sectors (Govt/BCS, Bank/Finance) and news publications (National Bangla, National English, International/Economy).
> - **Study Companion**: Built-in Pomodoro focus timer, active reading time logger per website, and daily preparation tracking.

---

### 1. Overview & Core Concept

- **What It Does**: JobPrep Guard acts as a secure study browser. Aspirants can seamlessly read editorials, check government circulars (Teletalk, BPSC, Bangladesh Bank e-Recruitment), and follow international current affairs without falling into distractions (social media, random search spirals, entertainment).
- **Target Audience / Persona**: Candidates preparing for 46th/47th BCS, Bangladesh Bank AD, Combined 9/10 Banks, Ministry recruitment tests, and primary/teacher recruitment exams.
- **Key Value**: 100% focused study environment. Saves time, eliminates digital distraction, and groups all essential circulars and daily editorials in one single touchpoint.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Hub / Dashboard**: 
   - Top banner: Daily study streak & Pomodoro focus timer quick-card (Play/Pause, preset 25m/50m sessions).
   - Category Pills / Filter chips: *All, সরকারি চাকরি (Govt Jobs), ব্যাংক রিক্রুটমেন্ট (Bank Jobs), জাতীয় সংবাদ (National News), আন্তর্জাতিক সংবাদ (International News), অর্থনৈতিক ও সম্পাদকীয় (Economy & Editorials)*.
   - Portal Cards: Rich Material 3 cards for each portal displaying name, logo/icon badge, category tag, and official domain URL.
2. **Safe Web Viewer (Lockdown Browser)**:
   - Tapping any portal launches the immersive Safe WebView.
   - **Header Bar**: Domain verification badge (e.g., `✔ bb.org.bd (Verified)`), page title, back, forward, reload, and close buttons. No address bar to type custom URLs.
   - **Link Interception Flow**: When a user taps a link inside the page:
     - If the target host matches the approved whitelist (or circular PDF document), it navigates normally.
     - If the target host is external (e.g. YouTube, Facebook, unknown blogs), navigation is blocked instantly, and a themed bottom sheet / dialog appears: *"এই লিংকটি আপনার জব প্রিপারেশন তালিকার অন্তর্ভুক্ত নয় (Access Restricted)"*.
3. **Study & Focus Companion Sheet/Screen**:
   - Track total reading time spent today.
   - View top visited portals (e.g., 35 mins on Prothom Alo Editorial, 20 mins on The Daily Star, 15 mins on Bangladesh Bank e-Recruitment).
   - Pomodoro timer with ambient focus sound toggle / vibration notification on completion.
4. **Favorites & Quick Access**:
   - Pin frequently visited portals (e.g. BPSC, BB e-Recruitment) to a "Fast Track" top horizontal carousel.

#### Visual Identity & Theme
- **Vibe**: Academic, focused, authoritative, distraction-free.
- **Color Palette**:
  - Primary: Deep Academic Emerald Green (`#0A5C36`) & Forest Jade (`#054425`) — symbolizing trust, Bangladesh government portal familiarity, and calm focus.
  - Secondary / Accent: Warm Sand Gold (`#D4A017`) — accentuating study streaks, timer badges, and active state indicators.
  - Surface & Background: Ultra-clean porcelain (`#F8FAF8`) for light theme; Deep Slate Charcoal (`#111613`) for night reading comfort.
  - Danger / Block Accent: Gentle Coral Red (`#C8372D`) for unauthorized link intercept dialogs.
- **Typography & Hierarchy**:
  - Banglish/Bangla & English dual typography: Clean sans-serif with distinct weights for headlines, portal titles, and domain chips.
- **Layout & Density**:
  - M3 Card grid with tonal elevation, responsive to orientation and compact/expanded screen sizes.

---

### 3. Key Product Decisions & Trade-Offs

- **Pre-Configured Whitelist with Strict Wildcard Matching**:
  - *Chosen Approach*: Maintain a curated domain hierarchy with subdomain support (e.g., `*.teletalk.com.bd` allows `alljobs`, `bpsc`, `dpe`, `ntrca`, etc.; `*.bb.org.bd` allows `erecruitment.bb.org.bd`).
  - *Why*: Teletalk and Bangladesh government domains rely extensively on subdomains for each ministry and exam. Wildcard matching ensures legitimate circulars and admit card download pages work seamlessly while blocking any foreign external domain.
- **Zero URL Bar Architecture**:
  - *Chosen Approach*: Omit the standard web address bar completely from the browser UI.
  - *Why*: Prevents typing arbitrary URLs, search queries, or circumvention attempts. Navigation happens exclusively via pre-verified launchpads and on-page internal links.
- **Integrated Local Study Persistence (Room / StateFlow)**:
  - *Chosen Approach*: Track study sessions, reading minutes per site, and favorites locally on-device.
  - *Why*: Fast, private, works offline for timer & logs, without requiring account creation or third-party cloud logins.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MainActivity (Compose Edge-to-Edge)             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
        ┌───────────────────────────┴───────────────────────────┐
        ▼                                                       ▼
┌───────────────────────────────┐               ┌───────────────────────────────┐
│     Home / Study Portal Hub   │               │     Safe Lockdown WebView     │
│  - Category Filter Chips      │               │  - Verified Domain Header Bar │
│  - Pinned Favorites Carousel  │               │  - Custom WebViewClient       │
│  - Portal Grid Cards          │◄─────────────►│    • shouldOverrideUrlLoading │
│  - Pomodoro Timer Widget      │  Launch Site  │    • Strict Domain Matcher    │
│  - Today's Study Stats        │  or Close     │    • Blocked URL Interceptor  │
└───────────────┬───────────────┘               └───────────────┬───────────────┘
                │                                               │
                │ Logs Reading Time                             │ Intercepts Unapproved
                ▼                                               ▼
┌───────────────────────────────┐               ┌───────────────────────────────┐
│      JobPrepRepository        │               │   Restriction Notice Sheet    │
│  - Whitelist Registry         │               │  - Friendly Alert Dialog      │
│  - Study Session Timer/Stats  │               │  - "সাইটটি অনুমোদিত নয়"       │
│  - Favorites Manager          │               │  - Return to Safe Page        │
└───────────────────────────────┘               └───────────────────────────────┘
```

#### Whitelist Master Registry (Curated for Job Prep)
1. **Govt & Exam Portals**:
   - `teletalk.com.bd` (AllJobs, BPSC, NTRCA, DPE, Railway, Ministries)
   - `bpsc.gov.bd` (Bangladesh Public Service Commission Official)
   - `bangladesh.gov.bd` (Bangladesh National Portal)
   - `dpe.gov.bd` (Directorate of Primary Education)
   - `moedu.gov.bd` (Ministry of Education)
2. **Bank & Financial Recruitment**:
   - `bb.org.bd` & `erecruitment.bb.org.bd` (Bangladesh Bank e-Recruitment)
   - `bibm.org.bd` (Bangladesh Institute of Bank Management)
3. **National Bengali Dailies**:
   - `prothomalo.com`
   - `bd-pratidin.com`
   - `ittefaq.com.bd`
   - `bonikbarta.net` (Business & Banking focus)
   - `jugantor.com`
   - `samakal.com`
4. **National English Dailies**:
   - `thedailystar.net`
   - `thefinancialexpress.com.bd`
   - `dhakatribune.com`
   - `tbsnews.net` (The Business Standard)
   - `newagebd.net`
5. **International News & Current Affairs**:
   - `bbc.com`, `bbc.co.uk`
   - `reuters.com`
   - `aljazeera.com`
   - `economist.com`
   - `project-syndicate.org`
6. **Career Opportunities**:
   - `bdjobs.com`
   - `chakrirkhobor.net`
