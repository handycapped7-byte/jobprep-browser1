package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.JobPrepRepository
import com.example.data.WhitelistRegistry
import com.example.data.local.JobPrepDatabase
import com.example.ui.screens.PortalHubScreen
import com.example.ui.screens.SafeLockdownBrowserScreen
import com.example.ui.screens.StudyTrackerScreen
import com.example.ui.screens.WhitelistRulesScreen
import com.example.ui.theme.JobPrepGuardTheme
import com.example.viewmodel.JobPrepViewModel
import com.example.viewmodel.MainTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val systemDark = isSystemInDarkTheme()
            val prefs = remember {
                context.getSharedPreferences("jobprep_theme_prefs", Context.MODE_PRIVATE)
            }
            val repository = remember {
                val db = JobPrepDatabase.getInstance(context)
                JobPrepRepository(db.jobPrepDao())
            }
            val viewModel: JobPrepViewModel = viewModel(
                factory = JobPrepViewModel.Factory(repository)
            )

            LaunchedEffect(Unit) {
                val savedDark = if (prefs.contains("is_dark_mode")) {
                    prefs.getBoolean("is_dark_mode", false)
                } else {
                    systemDark
                }
                viewModel.setInitialDarkMode(savedDark)
            }

            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            JobPrepGuardTheme(darkTheme = isDarkMode) {
                JobPrepGuardApp(
                    viewModel = viewModel,
                    onToggleTheme = {
                        val nextDark = !isDarkMode
                        viewModel.toggleDarkMode()
                        prefs.edit().putBoolean("is_dark_mode", nextDark).apply()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobPrepGuardApp(
    viewModel: JobPrepViewModel,
    onToggleTheme: () -> Unit = { viewModel.toggleDarkMode() }
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val filteredPortals by viewModel.filteredPortals.collectAsStateWithLifecycle()
    val pinnedPortalIds by viewModel.pinnedPortalIds.collectAsStateWithLifecycle()
    val activePortal by viewModel.activePortal.collectAsStateWithLifecycle()
    val blockedNotice by viewModel.blockedNotice.collectAsStateWithLifecycle()

    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val isAdBlockEnabled by viewModel.isAdBlockEnabled.collectAsStateWithLifecycle()
    val pageAdsBlockedCount by viewModel.pageAdsBlockedCount.collectAsStateWithLifecycle()
    val totalAdsBlockedCount by viewModel.totalAdsBlockedCount.collectAsStateWithLifecycle()

    val todayStudyMinutes by viewModel.todayStudyMinutes.collectAsStateWithLifecycle()
    val allStudySessions by viewModel.allStudySessions.collectAsStateWithLifecycle()
    val todayChecklist by viewModel.todayChecklist.collectAsStateWithLifecycle()
    val recentBlockedAttempts by viewModel.recentBlockedAttempts.collectAsStateWithLifecycle()
    val totalBlockedCount by viewModel.totalBlockedCount.collectAsStateWithLifecycle()

    val timerRemainingSeconds by viewModel.timerRemainingSeconds.collectAsStateWithLifecycle()
    val timerTotalSeconds by viewModel.timerTotalSeconds.collectAsStateWithLifecycle()
    val isTimerRunning by viewModel.isTimerRunning.collectAsStateWithLifecycle()
    val browsingSeconds by viewModel.browsingSeconds.collectAsStateWithLifecycle()

    BackHandler(enabled = activePortal == null && currentTab != MainTab.PORTALS) {
        viewModel.selectTab(MainTab.PORTALS)
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            if (activePortal == null) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GppGood,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = stringResource(R.string.app_subtitle),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    actions = {
                        // Global Light / Dark Mode Theme Toggle Button for Late-Night Study
                        FilledTonalIconButton(
                            onClick = onToggleTheme,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isDarkMode) Color(0xFFF4C44E) else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .size(48.dp)
                                .testTag("theme_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode"
                            )
                        }

                        val ytPortal = remember {
                            WhitelistRegistry.portals.find { it.id == "youtube_main" }
                        }
                        if (ytPortal != null) {
                            FilledTonalButton(
                                onClick = { viewModel.openPortal(ytPortal) },
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .testTag("topbar_youtube_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayCircleFilled,
                                    contentDescription = "Open YouTube Study",
                                    tint = Color(0xFFC62828),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "YouTube",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        },
        bottomBar = {
            if (activePortal == null) {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = currentTab == MainTab.PORTALS,
                        onClick = { viewModel.selectTab(MainTab.PORTALS) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.PORTALS) {
                                    Icons.Filled.Dashboard
                                } else {
                                    Icons.Outlined.Dashboard
                                },
                                contentDescription = stringResource(R.string.tab_portals)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_portals)) },
                        modifier = Modifier.testTag("nav_tab_portals")
                    )

                    NavigationBarItem(
                        selected = currentTab == MainTab.STUDY_TRACKER,
                        onClick = { viewModel.selectTab(MainTab.STUDY_TRACKER) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.STUDY_TRACKER) {
                                    Icons.Filled.Checklist
                                } else {
                                    Icons.Outlined.Checklist
                                },
                                contentDescription = stringResource(R.string.tab_study_tracker)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_study_tracker)) },
                        modifier = Modifier.testTag("nav_tab_tracker")
                    )

                    NavigationBarItem(
                        selected = currentTab == MainTab.WHITELIST_GUARD,
                        onClick = { viewModel.selectTab(MainTab.WHITELIST_GUARD) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == MainTab.WHITELIST_GUARD) {
                                    Icons.Filled.Shield
                                } else {
                                    Icons.Outlined.Shield
                                },
                                contentDescription = stringResource(R.string.tab_whitelist_rules)
                            )
                        },
                        label = { Text(stringResource(R.string.tab_whitelist_rules)) },
                        modifier = Modifier.testTag("nav_tab_whitelist")
                    )
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            val currentActivePortal = activePortal
            if (currentActivePortal != null) {
                SafeLockdownBrowserScreen(
                    portal = currentActivePortal,
                    browsingSeconds = browsingSeconds,
                    isPomodoroRunning = isTimerRunning,
                    pomodoroRemainingSeconds = timerRemainingSeconds,
                    isDarkMode = isDarkMode,
                    isAdBlockEnabled = isAdBlockEnabled,
                    pageAdsBlockedCount = pageAdsBlockedCount,
                    totalAdsBlockedCount = totalAdsBlockedCount,
                    blockedNotice = blockedNotice,
                    onToggleDarkMode = onToggleTheme,
                    onToggleAdBlock = { viewModel.toggleAdBlocker(it) },
                    onAdBlocked = { viewModel.onAdOrTrackerBlocked() },
                    onBlockedUrl = { blockedUrl ->
                        viewModel.onExternalUrlBlocked(blockedUrl, currentActivePortal)
                    },
                    onDismissBlockedNotice = { viewModel.dismissBlockedNotice() },
                    onSwitchPortal = { nextPortal -> viewModel.openPortal(nextPortal) },
                    onCloseBrowser = { viewModel.closeBrowser() }
                )
            } else {
                when (currentTab) {
                    MainTab.PORTALS -> {
                        PortalHubScreen(
                            portals = filteredPortals,
                            pinnedPortalIds = pinnedPortalIds,
                            selectedCategory = selectedCategory,
                            searchQuery = searchQuery,
                            todayStudyMinutes = todayStudyMinutes,
                            blockedCount = totalBlockedCount,
                            totalAdsBlockedCount = totalAdsBlockedCount,
                            timerRemainingSeconds = timerRemainingSeconds,
                            timerTotalSeconds = timerTotalSeconds,
                            isTimerRunning = isTimerRunning,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                            onTogglePin = { viewModel.togglePin(it) },
                            onOpenPortal = { viewModel.openPortal(it) },
                            onToggleTimer = { viewModel.togglePomodoroTimer() },
                            onResetTimer = { viewModel.resetPomodoroTimer() },
                            onSelectPresetMinutes = { viewModel.setPomodoroPreset(it) }
                        )
                    }

                    MainTab.STUDY_TRACKER -> {
                        StudyTrackerScreen(
                            todayStudyMinutes = todayStudyMinutes,
                            checklist = todayChecklist,
                            studySessions = allStudySessions,
                            onToggleChecklistItem = { viewModel.toggleChecklistItem(it) },
                            onAddChecklistTask = { title, sub ->
                                viewModel.addCustomChecklistTask(title, sub, null)
                            },
                            onOpenTargetPortal = { portalId ->
                                viewModel.openPortalById(portalId)
                            }
                        )
                    }

                    MainTab.WHITELIST_GUARD -> {
                        WhitelistRulesScreen(
                            isAdBlockEnabled = isAdBlockEnabled,
                            totalAdsBlockedCount = totalAdsBlockedCount,
                            recentBlockedAttempts = recentBlockedAttempts,
                            totalBlockedCount = totalBlockedCount,
                            onToggleAdBlock = { viewModel.toggleAdBlocker(it) },
                            onClearBlockedHistory = { viewModel.clearBlockedHistory() }
                        )
                    }
                }
            }
        }
    }
}
