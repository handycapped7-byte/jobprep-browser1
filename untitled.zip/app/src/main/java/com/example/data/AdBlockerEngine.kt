package com.example.data

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.URI

/**
 * Brave-style multi-layered Ad & Tracker Blocking Engine for JobPrep Guard.
 *
 * Layer 1: Network Request Interception (blocks ad/tracker domains & URL patterns before download)
 * Layer 2: Cosmetic CSS & DOM Filtering (hides empty ad placeholders & sticky banners on newspapers)
 * Layer 3: YouTube Ad Auto-Skipper & Feed Ad Cleaner
 */
object AdBlockerEngine {

    /**
     * Curated list of ad networks, trackers, telemetry servers, and regional BD ad networks
     * (such as Eskimi, PurplePatch, Adfinix, Google AdSense/DFP, Taboola, Outbrain).
     */
    val blockedAdDomains: Set<String> = setOf(
        // Google Ads, DoubleClick & AdSense
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "adservice.google.com.bd",
        "googletagservices.com",
        "googletagmanager.com",
        "google-analytics.com",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "ade.googlesyndication.com",
        "afs.googlesyndication.com",
        "fundingchoicesmessages.google.com",
        "imasdk.googleapis.com",

        // Global Display, Native & Programmatic Ad Networks
        "adnxs.com",
        "adsrvr.org",
        "criteo.com",
        "criteo.net",
        "taboola.com",
        "outbrain.com",
        "outbrainimg.com",
        "pubmatic.com",
        "rubiconproject.com",
        "openx.net",
        "moatads.com",
        "scorecardresearch.com",
        "quantserve.com",
        "zedo.com",
        "adroll.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "mgid.com",
        "revcontent.com",
        "adcolony.com",
        "smartadserver.com",
        "amazon-adsystem.com",
        "casalemedia.com",
        "indexww.com",
        "lijit.com",
        "sharethrough.com",
        "teads.tv",
        "3lift.com",
        "bidswitch.net",
        "advertising.com",
        "adform.net",
        "serving-sys.com",
        "flashtalking.com",
        "2mdn.net",
        "chartbeat.com",
        "chartbeat.net",
        "hotjar.com",
        "mouseflow.com",
        "clarity.ms",

        // Social Trackers & Pixels embedded inside Newspapers
        "connect.facebook.net",
        "facebook.net",
        "graph.facebook.com",
        "ads-twitter.com",
        "analytics.twitter.com",
        "bat.bing.com",
        "ads.linkedin.com",
        "tr.snapchat.com",

        // Regional Bangladesh Newspaper Ad Servers (Prothom Alo, Daily Star, Bdjobs, etc.)
        "eskimi.com",
        "dsp.eskimi.com",
        "purplepatch.online",
        "adfinix.com",
        "gands.com.bd",
        "wizardbd.com",
        "seopage1.net"
    )

    /**
     * URL path/query signatures strongly indicative of ad scripts, banners, and video ad pings.
     */
    private val blockedUrlKeywords: List<String> = listOf(
        "/pagead/",
        "/ads/ga-audiences",
        "adsbygoogle.js",
        "/gpt/pubads",
        "/gampad/ads",
        "/doubleclick/",
        "/adserver/",
        "/adframe.",
        "/adbanner/",
        "/popunder",
        "prebid.js",
        "/api/stats/ads",
        "/api/stats/qoe?adformat=",
        "/get_midroll_info",
        "&ad_type=",
        "?ad_type=",
        "/ptracking?html5=1"
    )

    /**
     * Evaluates whether a sub-resource or network URL is an advertisement or tracker.
     */
    fun isAdOrTrackerRequest(urlString: String?): Boolean {
        if (urlString.isNullOrBlank()) return false
        val lowerUrl = urlString.trim().lowercase()

        // 1. Check URL keywords / ad path signatures
        if (blockedUrlKeywords.any { lowerUrl.contains(it) }) {
            return true
        }

        // 2. Extract host and match against blockedAdDomains
        val host = extractHost(lowerUrl) ?: return false
        return isAdDomain(host)
    }

    fun isAdDomain(rawHost: String): Boolean {
        val cleanHost = rawHost.trim().lowercase().removePrefix("www.")
        if (cleanHost.isEmpty()) return false
        return blockedAdDomains.any { adDomain ->
            cleanHost == adDomain || cleanHost.endsWith(".$adDomain")
        }
    }

    private fun extractHost(url: String): String? {
        return try {
            URI(url).host?.lowercase()?.removePrefix("www.")
        } catch (e: Exception) {
            WhitelistRegistry.extractHostFallback(url)?.removePrefix("www.")
        }
    }

    /**
     * Creates an empty, instant 200 OK response to sinkhole blocked ad requests
     * without triggering WebView error pages.
     */
    fun createEmptyResourceResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            200,
            "OK",
            mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "no-store"
            ),
            ByteArrayInputStream(ByteArray(0))
        )
    }

    /**
     * Brave-style Cosmetic CSS & JavaScript Shield injected into pages.
     * - Collapses AdSense, GPT/DFP slots, sticky newspaper banners, popups, and Taboola/Outbrain widgets.
     * - Automatically skips YouTube video ads and hides YouTube promoted feed slots.
     */
    val cosmeticAdBlockJavaScript: String = """
        (function() {
            if (window.__jobPrepBraveShieldActive) return;
            window.__jobPrepBraveShieldActive = true;

            // 1. Inject Cosmetic Ad-Hiding CSS Rules
            const style = document.createElement('style');
            style.id = 'jobprep-brave-shield-css';
            style.innerHTML = `
                ins.adsbygoogle,
                .adsbygoogle,
                [id^="div-gpt-ad"],
                [id^="google_ads_iframe"],
                [id*="google_ads"],
                iframe[src*="doubleclick.net"],
                iframe[src*="googlesyndication.com"],
                iframe[src*="eskimi.com"],
                iframe[src*="purplepatch"],
                iframe[id^="google_ads"],
                .ad-container,
                .ad-wrapper,
                .ad-banner,
                .ad-slot,
                .ad-box,
                .dfp-ad,
                .dfp-tag-wrapper,
                .advertisement,
                .sponsored-box,
                .taboola-widget,
                .OUTBRAIN,
                [class*="ad-leaderboard"],
                [class*="sticky-ad"],
                [class*="floating-ad"],
                [id*="taboola"],
                [id*="outbrain"],
                ytm-promoted-sparkles-web-renderer,
                ytm-promoted-video-renderer,
                ytm-companion-ad-renderer,
                ytd-ad-slot-renderer,
                ytd-promoted-sparkles-web-renderer,
                ytd-display-ad-renderer,
                .ytp-ad-overlay-container,
                .ytp-ad-message-container,
                #masthead-ad,
                #player-ads {
                    display: none !important;
                    height: 0 !important;
                    min-height: 0 !important;
                    max-height: 0 !important;
                    visibility: hidden !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                    overflow: hidden !important;
                }
            `;
            if (document.head) {
                document.head.appendChild(style);
            } else {
                document.addEventListener('DOMContentLoaded', function() {
                    if (document.head) document.head.appendChild(style);
                });
            }

            // 2. Active DOM Cleaner & YouTube Video Ad Auto-Skipper
            function cleanAdsAndSkipYouTubeAds() {
                try {
                    // Remove generic ad nodes
                    const adSelectors = [
                        'ins.adsbygoogle',
                        '[id^="div-gpt-ad"]',
                        '[id^="google_ads_iframe"]',
                        'ytm-promoted-sparkles-web-renderer',
                        'ytm-companion-ad-renderer',
                        '.ytp-ad-overlay-slot'
                    ];
                    adSelectors.forEach(function(sel) {
                        document.querySelectorAll(sel).forEach(function(el) {
                            el.style.setProperty('display', 'none', 'important');
                        });
                    });

                    // YouTube specific ad-skipping logic
                    const skipButtons = document.querySelectorAll(
                        '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .videoAdUiSkipButton'
                    );
                    skipButtons.forEach(function(btn) {
                        if (btn && typeof btn.click === 'function') {
                            btn.click();
                        }
                    });

                    // Fast-forward unskippable YouTube video ads immediately
                    const adPlayer = document.querySelector('.ad-showing video, .ad-interrupting video');
                    if (adPlayer && !isNaN(adPlayer.duration) && adPlayer.duration > 0) {
                        adPlayer.muted = true;
                        adPlayer.currentTime = adPlayer.duration;
                    }
                } catch (err) {}
            }

            cleanAdsAndSkipYouTubeAds();
            setInterval(cleanAdsAndSkipYouTubeAds, 600);
        })();
    """.trimIndent()
}
