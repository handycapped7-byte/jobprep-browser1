package com.example.data

import com.example.data.local.BlockedAttemptEntity
import com.example.data.local.DailyChecklistEntity
import com.example.data.local.FavoritePortalEntity
import com.example.data.local.JobPrepDao
import com.example.data.local.StudySessionEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JobPrepRepository(private val dao: JobPrepDao) {

    fun currentDateKey(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    val allStudySessions: Flow<List<StudySessionEntity>> = dao.getAllStudySessions()
    val pinnedPortalsFlow: Flow<List<FavoritePortalEntity>> = dao.getPinnedPortals()
    val recentBlockedAttempts: Flow<List<BlockedAttemptEntity>> = dao.getRecentBlockedAttempts()
    val totalBlockedCount: Flow<Int> = dao.getTotalBlockedCount()

    fun getTodayStudyMinutes(): Flow<Int> = dao.getTodayStudyMinutes(currentDateKey())

    fun getTodayChecklist(): Flow<List<DailyChecklistEntity>> = dao.getChecklistForDate(currentDateKey())

    suspend fun ensureDefaultsInitialized() {
        val favCount = dao.getFavoritesEntryCount()
        if (favCount == 0) {
            WhitelistRegistry.portals.filter { it.defaultPinned }.forEach { portal ->
                dao.upsertFavorite(
                    FavoritePortalEntity(
                        portalId = portal.id,
                        isPinned = true
                    )
                )
            }
        }

        val today = currentDateKey()
        val checklistCount = dao.getChecklistCountForDate(today)
        if (checklistCount == 0) {
            val defaultTasks = listOf(
                DailyChecklistEntity(
                    titleBn = "প্রথম আলো ও বণিক বার্তা সম্পাদকীয় পড়া",
                    subtitleBn = "জাতীয় ও অর্থনৈতিক গুরুত্বপূর্ণ কলাম নোট করা (২০ মিনিট)",
                    targetPortalId = "prothom_alo",
                    isCompleted = false,
                    dateKey = today
                ),
                DailyChecklistEntity(
                    titleBn = "The Daily Star ও Financial Express Editorial",
                    subtitleBn = "ইংরেজি ভোকাবুলারি ও ফোকাস রাইটিং অনুবাদ অনুশীলন",
                    targetPortalId = "daily_star_editorial",
                    isCompleted = false,
                    dateKey = today
                ),
                DailyChecklistEntity(
                    titleBn = "টেলিটক অল জবস ও বিপিএসসি নোটিশ চেক",
                    subtitleBn = "নতুন সরকারি সার্কুলার ও পরীক্ষার সময়সূচি যাচাই",
                    targetPortalId = "teletalk_alljobs",
                    isCompleted = false,
                    dateKey = today
                ),
                DailyChecklistEntity(
                    titleBn = "বাংলাদেশ ব্যাংক ই-রিক্রুটমেন্ট সার্কুলার যাচাই",
                    subtitleBn = "ব্যাংক জব বিজ্ঞপ্তি ও অ্যাডমিট কার্ড আপডেট দেখা",
                    targetPortalId = "bb_erecruitment",
                    isCompleted = false,
                    dateKey = today
                ),
                DailyChecklistEntity(
                    titleBn = "আন্তর্জাতিক বিষয়াবলী (BBC বাংলা ও Reuters)",
                    subtitleBn = "বিশ্ব রাজনীতি ও সাম্প্রতিক আন্তর্জাতিক ঘটনা প্রবাহ পড়া",
                    targetPortalId = "bbc_bengali",
                    isCompleted = false,
                    dateKey = today
                ),
                DailyChecklistEntity(
                    titleBn = "ইউটিউবে গণিত/ইংরেজি/সাধারণ জ্ঞান ভিডিও লেকচার",
                    subtitleBn = "কমপক্ষে ১টি জব প্রিপারেশন টিউটোরিয়াল ক্লাস সম্পন্ন করা",
                    targetPortalId = "youtube_bcs_bank",
                    isCompleted = false,
                    dateKey = today
                )
            )
            defaultTasks.forEach { dao.insertChecklistItem(it) }
        }
    }

    suspend fun togglePinPortal(portalId: String, currentlyPinned: Boolean) {
        dao.upsertFavorite(
            FavoritePortalEntity(
                portalId = portalId,
                isPinned = !currentlyPinned
            )
        )
    }

    suspend fun logStudySession(portal: JobPrepPortal, durationMinutes: Int) {
        if (durationMinutes <= 0) return
        dao.insertStudySession(
            StudySessionEntity(
                portalId = portal.id,
                portalName = portal.nameBn,
                categoryName = portal.category.titleBn,
                durationMinutes = durationMinutes,
                dateKey = currentDateKey()
            )
        )
    }

    suspend fun logBlockedUrl(blockedUrl: String, blockedDomain: String, sourcePortalName: String) {
        dao.insertBlockedAttempt(
            BlockedAttemptEntity(
                blockedUrl = blockedUrl,
                blockedDomain = blockedDomain,
                sourcePortalName = sourcePortalName
            )
        )
    }

    suspend fun clearBlockedHistory() {
        dao.clearBlockedAttempts()
    }

    suspend fun toggleChecklistTask(id: Long, completed: Boolean) {
        dao.updateChecklistCompletion(id, completed)
    }

    suspend fun addCustomChecklistTask(titleBn: String, subtitleBn: String, targetPortalId: String?) {
        dao.insertChecklistItem(
            DailyChecklistEntity(
                titleBn = titleBn,
                subtitleBn = subtitleBn,
                targetPortalId = targetPortalId,
                isCompleted = false,
                dateKey = currentDateKey()
            )
        )
    }
}
