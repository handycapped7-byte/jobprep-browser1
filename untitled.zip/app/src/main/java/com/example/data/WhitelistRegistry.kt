package com.example.data

import java.net.URI

enum class PortalCategory(
    val titleBn: String,
    val titleEn: String
) {
    ALL("সব পোর্টাল", "All Portals"),
    GOVT_JOBS("সরকারি ও টেলিটক (★)", "Govt & Teletalk"),
    BANK_JOBS("ব্যাংক রিক্রুটমেন্ট", "Bank Recruitment"),
    VIDEO_LEARNING("ইউটিউব ও লেকচার", "YouTube & Lectures"),
    NATIONAL_BANGLA("জাতীয় বাংলা পত্রিকা", "Bangla Newspapers"),
    NATIONAL_ENGLISH("ইংরেজি দৈনিক ও সম্পাদকীয়", "English Dailies"),
    INTERNATIONAL_NEWS("আন্তর্জাতিক ও অর্থনীতি", "Global & Economy")
}

data class JobPrepPortal(
    val id: String,
    val nameBn: String,
    val nameEn: String,
    val subtitle: String,
    val url: String,
    val primaryDomain: String,
    val category: PortalCategory,
    val badgeText: String,
    val accentHex: Long,
    val defaultPinned: Boolean = false
)

data class TeletalkDepartmentPreset(
    val code: String,
    val nameBn: String,
    val nameEn: String,
    val url: String = "http://$code.teletalk.com.bd"
)

object WhitelistRegistry {

    /**
     * Strictly curated list of root domains allowed in the Lockdown Browser.
     * Wildcard subdomain matching is enforced automatically:
     * - "*.teletalk.com.bd" and "*.teletalk.bd" allow ALL Teletalk recruitment portals
     *   (e.g., dcd.teletalk.com.bd, bogmc.teletalk.com.bd, bogmc.teletalk.bd, railway.teletalk.com.bd, etc.)
     * - "*.gov.bd" allows all Bangladesh Government ministry & department websites.
     */
    val approvedRootDomains: Set<String> = setOf(
        // Wildcard Teletalk & Govt Domains (*.teletalk.com.bd, *.teletalk.bd, *.gov.bd)
        "teletalk.com.bd",
        "teletalk.bd",
        "gov.bd",
        "bpsc.gov.bd",
        "bangladesh.gov.bd",
        "dpe.gov.bd",
        "ntrca.gov.bd",
        "moedu.gov.bd",
        "mopa.gov.bd",
        "mof.gov.bd",
        "forms.gov.bd",
        "bdjobs.com",
        "mybdjobs.bdjobs.com",

        // Bank & Financial Institutions
        "bb.org.bd",
        "bibm.org.bd",
        "sonalibank.com.bd",
        "janatabank-bd.com",
        "agranibank.org",
        "rupali.com.bd",
        "pksf.org.bd",

        // YouTube, Video Stream Assets & Google Sign-In for YouTube
        "youtube.com",
        "youtu.be",
        "googlevideo.com",
        "ytimg.com",
        "ggpht.com",
        "youtube-nocookie.com",
        "accounts.google.com",
        "accounts.youtube.com",
        "myaccount.google.com",
        "gstatic.com",
        "googleapis.com",
        "googleusercontent.com",

        // National Bangla Newspapers
        "prothomalo.com",
        "bonikbarta.net",
        "ittefaq.com.bd",
        "samakal.com",
        "jugantor.com",
        "bd-pratidin.com",
        "kalerkantho.com",
        "nayadiganta.com",
        "mzamin.com",
        "bhorerkagoj.com",
        "jaijaidinbd.com",
        "deshrupantor.com",

        // National English Newspapers (Editorial & Vocabulary Prep)
        "thedailystar.net",
        "thefinancialexpress.com.bd",
        "tbsnews.net",
        "dhakatribune.com",
        "newagebd.net",
        "daily-sun.com",
        "observerbd.com",

        // International News, Current Affairs & Global Economy
        "bbc.com",
        "bbc.co.uk",
        "bbci.co.uk",
        "reuters.com",
        "aljazeera.com",
        "economist.com",
        "project-syndicate.org",
        "weforum.org",
        "worldbank.org",
        "imf.org",
        "un.org",
        "adb.org"
    )

    /**
     * Quick presets for popular Teletalk department subdomains (*.teletalk.com.bd)
     * plus users can type ANY department code to open <code >.teletalk.com.bd.
     */
    val teletalkDepartmentPresets: List<TeletalkDepartmentPreset> = listOf(
        TeletalkDepartmentPreset("alljobs", "AllJobs (সকল চাকরি)", "AllJobs Master Portal", "https://alljobs.teletalk.com.bd"),
        TeletalkDepartmentPreset("dcd", "সমবায় অধিদপ্তর (DCD)", "Department of Cooperatives"),
        TeletalkDepartmentPreset("bogmc", "পেট্রোবাংলা (BOGMC)", "Petrobangla / BOGMC"),
        TeletalkDepartmentPreset("bpsc", "বিপিএসসি (BPSC)", "Public Service Commission"),
        TeletalkDepartmentPreset("dpe", "প্রাথমিক শিক্ষা (DPE)", "Directorate of Primary Education"),
        TeletalkDepartmentPreset("ntrca", "শিক্ষক নিবন্ধন (NTRCA)", "NTRCA Recruitment"),
        TeletalkDepartmentPreset("railway", "বাংলাদেশ রেলওয়ে (BR)", "Bangladesh Railway"),
        TeletalkDepartmentPreset("dghs", "স্বাস্থ্য অধিদপ্তর (DGHS)", "Directorate General of Health Services"),
        TeletalkDepartmentPreset("dgfp", "পরিবার পরিকল্পনা (DGFP)", "Directorate General of Family Planning"),
        TeletalkDepartmentPreset("dae", "কৃষি সম্প্রসারণ (DAE)", "Department of Agricultural Extension"),
        TeletalkDepartmentPreset("lgd", "স্থানীয় সরকার বিভাগ (LGD)", "Local Government Division"),
        TeletalkDepartmentPreset("lged", "এলজিইডি (LGED)", "Local Government Engineering Dept"),
        TeletalkDepartmentPreset("cga", "হিসাব মহানিয়ন্ত্রক (CGA)", "Controller General of Accounts"),
        TeletalkDepartmentPreset("nbr", "জাতীয় রাজস্ব বোর্ড (NBR)", "National Board of Revenue"),
        TeletalkDepartmentPreset("bwdb", "পানি উন্নয়ন বোর্ড (BWDB)", "Water Development Board"),
        TeletalkDepartmentPreset("bpdb", "বিদ্যুৎ উন্নয়ন বোর্ড (BPDB)", "Power Development Board"),
        TeletalkDepartmentPreset("breb", "পল্লী বিদ্যুতায়ন বোর্ড (BREB)", "Rural Electrification Board"),
        TeletalkDepartmentPreset("bcic", "বিসিআইসি (BCIC)", "Chemical Industries Corporation"),
        TeletalkDepartmentPreset("badc", "বিএডিসি (BADC)", "Agricultural Development Corp"),
        TeletalkDepartmentPreset("pwd", "গণপূর্ত অধিদপ্তর (PWD)", "Public Works Department"),
        TeletalkDepartmentPreset("rhd", "সড়ক ও জনপথ (RHD)", "Roads and Highways Department"),
        TeletalkDepartmentPreset("phe", "জনস্বাস্থ্য প্রকৌশল (DPHE)", "Dept of Public Health Engineering"),
        TeletalkDepartmentPreset("dss", "সমাজসেবা অধিদপ্তর (DSS)", "Department of Social Services"),
        TeletalkDepartmentPreset("dyd", "যুব উন্নয়ন অধিদপ্তর (DYD)", "Department of Youth Development"),
        TeletalkDepartmentPreset("dgfood", "খাদ্য অধিদপ্তর (DGFood)", "Directorate General of Food"),
        TeletalkDepartmentPreset("bbs", "পরিসংখ্যান ব্যুরো (BBS)", "Bangladesh Bureau of Statistics"),
        TeletalkDepartmentPreset("dip", "ইমিগ্রেশন ও পাসপোর্ট (DIP)", "Department of Immigration & Passports"),
        TeletalkDepartmentPreset("police", "বাংলাদেশ পুলিশ (Police)", "Bangladesh Police Recruitment"),
        TeletalkDepartmentPreset("ansar", "আনসার ও ভিডিপি (Ansar)", "Bangladesh Ansar & VDP"),
        TeletalkDepartmentPreset("fire", "ফায়ার সার্ভিস (FSCD)", "Fire Service & Civil Defence"),
        TeletalkDepartmentPreset("biman", "বিমান বাংলাদেশ (Biman)", "Biman Bangladesh Airlines"),
        TeletalkDepartmentPreset("caab", "বেসামরিক বিমান চলাচল (CAAB)", "Civil Aviation Authority"),
        TeletalkDepartmentPreset("cpa", "চট্টগ্রাম বন্দর (CPA)", "Chittagong Port Authority"),
        TeletalkDepartmentPreset("brta", "বিআরটিএ (BRTA)", "Bangladesh Road Transport Authority")
    )

    /**
     * Builds a valid Teletalk portal JobPrepPortal object for ANY department code or full Teletalk domain
     * (e.g., "dcd", "dcd.teletalk.com.bd", "bogmc.teletalk.bd", "railway").
     */
    fun createCustomTeletalkPortal(rawInput: String): JobPrepPortal? {
        val cleaned = rawInput.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("www.")
            .substringBefore("/")
            .substringBefore("?")
            .trim()

        if (cleaned.isEmpty()) return null

        val fullDomain = when {
            cleaned.endsWith(".teletalk.com.bd") || cleaned.endsWith(".teletalk.bd") -> cleaned
            cleaned == "teletalk.com.bd" || cleaned == "teletalk.bd" -> "alljobs.teletalk.com.bd"
            // Allow alphanumeric & hyphen department codes like "dcd", "bogmc", "tax10"
            cleaned.matches(Regex("^[a-z0-9-]+$")) -> "$cleaned.teletalk.com.bd"
            else -> return null
        }

        if (!isDomainAllowed(fullDomain)) return null

        val deptCode = fullDomain.substringBefore(".")
        val preset = teletalkDepartmentPresets.find { it.code.equals(deptCode, ignoreCase = true) }
        val url = preset?.url ?: "http://$fullDomain"

        return JobPrepPortal(
            id = "teletalk_dept_$deptCode",
            nameBn = preset?.nameBn ?: "টেলিটক পোর্টাল (${deptCode.uppercase()})",
            nameEn = preset?.nameEn ?: "${deptCode.uppercase()} Teletalk Recruitment Portal",
            subtitle = "সরাসরি অনলাইন আবেদন, প্রবেশপত্র ও ফলাফল: $fullDomain",
            url = url,
            primaryDomain = fullDomain,
            category = PortalCategory.GOVT_JOBS,
            badgeText = "★.teletalk.com.bd",
            accentHex = 0xFF0A5C36
        )
    }

    val portals: List<JobPrepPortal> = listOf(
        // ================= GOVT & TELETALK JOBS =================
        JobPrepPortal(
            id = "teletalk_alljobs",
            nameBn = "টেলিটক অল জবস (AllJobs Master)",
            nameEn = "Teletalk AllJobs Portal",
            subtitle = "সকল সরকারি চাকরি, মন্ত্রণালয় ও অধিদপ্তরের একীভূত আবেদন পোর্টাল (alljobs.teletalk.com.bd)",
            url = "https://alljobs.teletalk.com.bd",
            primaryDomain = "alljobs.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "সরকারি আবেদন",
            accentHex = 0xFF0A5C36,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "dcd_teletalk",
            nameBn = "সমবায় অধিদপ্তর টেলিটক (DCD)",
            nameEn = "Department of Cooperatives (dcd.teletalk.com.bd)",
            subtitle = "সমবায় অধিদপ্তরের (DCD) সকল পদের অনলাইন আবেদন ও প্রবেশপত্র ডাউনলোড",
            url = "http://dcd.teletalk.com.bd",
            primaryDomain = "dcd.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "DCD Teletalk",
            accentHex = 0xFF0D683F,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bogmc_teletalk",
            nameBn = "পেট্রোবাংলা / BOGMC টেলিটক",
            nameEn = "Petrobangla BOGMC (bogmc.teletalk.com.bd)",
            subtitle = "বাংলাদেশ তৈল, গ্যাস ও খনিজ সম্পদ কর্পোরেশন (BOGMC) নিয়োগ পোর্টাল",
            url = "http://bogmc.teletalk.com.bd",
            primaryDomain = "bogmc.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "BOGMC Teletalk",
            accentHex = 0xFF145A32,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bpsc_official",
            nameBn = "বাংলাদেশ সরকারি কর্ম কমিশন (BPSC)",
            nameEn = "BPSC Official Portal",
            subtitle = "বিসিএস ও নন-ক্যাডার পরীক্ষার অফিসিয়াল বিজ্ঞপ্তি, সিলেবাস ও ফলাফল",
            url = "https://bpsc.gov.bd",
            primaryDomain = "bpsc.gov.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "বিসিএস",
            accentHex = 0xFF054425,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bpsc_teletalk",
            nameBn = "বিপিএসসি টেলিটক (BPSC Exam)",
            nameEn = "BPSC Teletalk Registration",
            subtitle = "বিসিএস পরীক্ষার সরাসরি অনলাইন ফরম পূরণ ও অ্যাডমিট কার্ড ডাউনলোড",
            url = "http://bpsc.teletalk.com.bd",
            primaryDomain = "bpsc.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "বিসিএস ফরম",
            accentHex = 0xFF0F6B40,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "dpe_teletalk",
            nameBn = "প্রাথমিক শিক্ষক নিয়োগ (DPE Teletalk)",
            nameEn = "Directorate of Primary Education",
            subtitle = "সরকারি প্রাথমিক বিদ্যালয়ে সহকারী শিক্ষক নিয়োগ আবেদন (dpe.teletalk.com.bd)",
            url = "http://dpe.teletalk.com.bd",
            primaryDomain = "dpe.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "প্রাথমিক শিক্ষা",
            accentHex = 0xFF1A6B54,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "ntrca_portal",
            nameBn = "এনটিআরসিএ শিক্ষক নিবন্ধন (NTRCA)",
            nameEn = "NTRCA Exam & e-Requisition",
            subtitle = "বেসরকারি শিক্ষক নিবন্ধন ও প্রত্যয়ন কর্তৃপক্ষের বিজ্ঞপ্তি ও আবেদন",
            url = "http://ntrca.teletalk.com.bd",
            primaryDomain = "ntrca.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "শিক্ষক নিবন্ধন",
            accentHex = 0xFF1F5E3B,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "railway_teletalk",
            nameBn = "বাংলাদেশ রেলওয়ে টেলিটক (Railway)",
            nameEn = "Bangladesh Railway Recruitment",
            subtitle = "বাংলাদেশ রেলওয়ের সকল গ্রেডের নিয়োগ বিজ্ঞপ্তি ও অনলাইন আবেদন",
            url = "http://railway.teletalk.com.bd",
            primaryDomain = "railway.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "রেলওয়ে জব",
            accentHex = 0xFF1B4F72,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "dghs_teletalk",
            nameBn = "স্বাস্থ্য অধিদপ্তর টেলিটক (DGHS)",
            nameEn = "DGHS Teletalk Portal",
            subtitle = "স্বাস্থ্য অধিদপ্তরের অধীনে বিভিন্ন পদে অনলাইন আবেদন ও প্রবেশপত্র",
            url = "http://dghs.teletalk.com.bd",
            primaryDomain = "dghs.teletalk.com.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "স্বাস্থ্য বিভাগ",
            accentHex = 0xFF0E6251,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "bd_national_portal",
            nameBn = "জাতীয় তথ্য বাতায়ন (Bangladesh.gov.bd)",
            nameEn = "Bangladesh National Portal",
            subtitle = "সকল মন্ত্রণালয়, বিভাগ ও অধিদপ্তরের অফিসিয়াল নোটিশ এবং তথ্যসমূহ (*.gov.bd)",
            url = "https://bangladesh.gov.bd",
            primaryDomain = "bangladesh.gov.bd",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "সরকারি বাতায়ন",
            accentHex = 0xFF085038,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "bdjobs_portal",
            nameBn = "বিডিজবস (Bdjobs.com)",
            nameEn = "Bdjobs Career Portal",
            subtitle = "সরকারি, স্বায়ত্তশাসিত ও শীর্ষ বেসরকারি প্রতিষ্ঠানের চাকরির বিজ্ঞপ্তি",
            url = "https://www.bdjobs.com",
            primaryDomain = "bdjobs.com",
            category = PortalCategory.GOVT_JOBS,
            badgeText = "জব সার্কুলার",
            accentHex = 0xFF0D47A1,
            defaultPinned = false
        ),

        // ================= BANK & FINANCE JOBS =================
        JobPrepPortal(
            id = "bb_erecruitment",
            nameBn = "বাংলাদেশ ব্যাংক ই-রিক্রুটমেন্ট",
            nameEn = "Bangladesh Bank e-Recruitment",
            subtitle = "সহকারী পরিচালক (AD), অফিসার ও সমন্বিত ব্যাংক নিয়োগের অফিসিয়াল পোর্টাল",
            url = "https://erecruitment.bb.org.bd",
            primaryDomain = "erecruitment.bb.org.bd",
            category = PortalCategory.BANK_JOBS,
            badgeText = "ব্যাংক জব",
            accentHex = 0xFF004D40,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bb_official",
            nameBn = "বাংলাদেশ ব্যাংক (Official)",
            nameEn = "Bangladesh Bank Main Portal",
            subtitle = "মুদ্রানীতি, অর্থনৈতিক সূচক, বার্ষিক প্রতিবেদন ও ব্যাংকিং তথ্য (ভাইভা প্রস্তুতি)",
            url = "https://www.bb.org.bd",
            primaryDomain = "bb.org.bd",
            category = PortalCategory.BANK_JOBS,
            badgeText = "কেন্দ্রীয় ব্যাংক",
            accentHex = 0xFF00695C,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "bibm_portal",
            nameBn = "বিআইবিএম (BIBM)",
            nameEn = "Bangladesh Institute of Bank Management",
            subtitle = "ব্যাংকিং গবেষণা, সেমিনার ও ব্যাংক নিয়োগ পরীক্ষা সংক্রান্ত তথ্য",
            url = "https://www.bibm.org.bd",
            primaryDomain = "bibm.org.bd",
            category = PortalCategory.BANK_JOBS,
            badgeText = "ব্যাংকিং ইনস্টিটিউট",
            accentHex = 0xFF1B5E20,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "mof_bd",
            nameBn = "অর্থ মন্ত্রণালয় (Ministry of Finance)",
            nameEn = "Finance Division Bangladesh",
            subtitle = "জাতীয় বাজেট, বাংলাদেশ অর্থনৈতিক সমীক্ষা (Economic Review) ও প্রজ্ঞাপন",
            url = "https://mof.gov.bd",
            primaryDomain = "mof.gov.bd",
            category = PortalCategory.BANK_JOBS,
            badgeText = "অর্থনৈতিক সমীক্ষা",
            accentHex = 0xFF33691E,
            defaultPinned = false
        ),

        // ================= YOUTUBE & VIDEO LECTURES =================
        JobPrepPortal(
            id = "youtube_main",
            nameBn = "ইউটিউব (YouTube Study)",
            nameEn = "YouTube Video Platform",
            subtitle = "জব প্রিপারেশন ক্লাস, গণিত, ইংরেজি, সাধারণ জ্ঞান ও সম্পাদকীয় বিশ্লেষণ ভিডিও",
            url = "https://m.youtube.com",
            primaryDomain = "youtube.com",
            category = PortalCategory.VIDEO_LEARNING,
            badgeText = "ভিডিও ক্লাস",
            accentHex = 0xFFC62828,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "youtube_bcs_bank",
            nameBn = "বিসিএস ও ব্যাংক জব লেকচার (YouTube)",
            nameEn = "YouTube BCS & Bank Prep",
            subtitle = "সরাসরি বিসিএস, বাংলাদেশ ব্যাংক এডি ও সরকারি চাকরির প্রস্তুতিমূলক লেকচার ফিড",
            url = "https://m.youtube.com/results?search_query=BCS+and+Bank+Job+Preparation+Bangladesh",
            primaryDomain = "youtube.com",
            category = PortalCategory.VIDEO_LEARNING,
            badgeText = "নির্বাচিত সার্চ",
            accentHex = 0xFFB71C1C,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "youtube_editorial",
            nameBn = "দৈনিক সম্পাদকীয় ও কারেন্ট অ্যাফেয়ার্স (YouTube)",
            nameEn = "YouTube Daily Editorial Translation",
            subtitle = "ইংরেজি পত্রিকার সম্পাদকীয় অনুবাদ, ভোকাবুলারি ও আন্তর্জাতিক বিষয়াবলী বিশ্লেষণ",
            url = "https://m.youtube.com/results?search_query=Daily+Star+Editorial+Translation+BCS+Bank+Job",
            primaryDomain = "youtube.com",
            category = PortalCategory.VIDEO_LEARNING,
            badgeText = "এডিটোরিয়াল ক্লাস",
            accentHex = 0xFFD84315,
            defaultPinned = false
        ),

        // ================= NATIONAL BANGLA NEWSPAPERS =================
        JobPrepPortal(
            id = "prothom_alo",
            nameBn = "দৈনিক প্রথম আলো",
            nameEn = "Prothom Alo",
            subtitle = "জাতীয় সংবাদ, মতামত, সম্পাদকীয় এবং চাকরি ও ক্যারিয়ার পাতা",
            url = "https://www.prothomalo.com",
            primaryDomain = "prothomalo.com",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় দৈনিক",
            accentHex = 0xFF1565C0,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bonik_barta",
            nameBn = "বণিক বার্তা (Bonik Barta)",
            nameEn = "Bonik Barta Business Daily",
            subtitle = "ব্যাংকিং খাত, অর্থনীতি, বাণিজ্য ও বিশেষ সম্পাদকীয় (ব্যাংক ও বিসিএস রিটেন প্রস্তুতি)",
            url = "https://bonikbarta.net",
            primaryDomain = "bonikbarta.net",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "অর্থনীতি ও ব্যাংকিং",
            accentHex = 0xFF8D6E63,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "daily_ittefaq",
            nameBn = "দৈনিক ইত্তেফাক",
            nameEn = "The Daily Ittefaq",
            subtitle = "ঐতিহ্যবাহী জাতীয় পত্রিকা, দেশ-বিদেশের খবর ও সমসাময়িক বিশ্লেষণ",
            url = "https://www.ittefaq.com.bd",
            primaryDomain = "ittefaq.com.bd",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় সংবাদ",
            accentHex = 0xFF283593,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "samakal",
            nameBn = "দৈনিক সমকাল",
            nameEn = "Daily Samakal",
            subtitle = "জাতীয়, অর্থনীতি, মুক্তমঞ্চ ও চাকরি প্রস্তুতির নিয়মিত ফিচার",
            url = "https://samakal.com",
            primaryDomain = "samakal.com",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় দৈনিক",
            accentHex = 0xFF2E7D32,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "jugantor",
            nameBn = "দৈনিক যুগান্তর",
            nameEn = "Daily Jugantor",
            subtitle = "জাতীয় সংবাদ, অর্থনীতি, আন্তর্জাতিক ও চাকরির খবর",
            url = "https://www.jugantor.com",
            primaryDomain = "jugantor.com",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় সংবাদ",
            accentHex = 0xFF4527A0,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "kaler_kantho",
            nameBn = "দৈনিক কালের কণ্ঠ",
            nameEn = "Kaler Kantho",
            subtitle = "জাতীয় খবর, উপসম্পাদকীয়, শিক্ষা ও চাকরির প্রস্তুতি পাতা",
            url = "https://www.kalerkantho.com",
            primaryDomain = "kalerkantho.com",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় দৈনিক",
            accentHex = 0xFF00838F,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "bd_pratidin",
            nameBn = "বাংলাদেশ প্রতিদিন",
            nameEn = "Bangladesh Pratidin",
            subtitle = "সর্বশেষ জাতীয় ও আন্তর্জাতিক সংবাদ এবং কলাম",
            url = "https://www.bd-pratidin.com",
            primaryDomain = "bd-pratidin.com",
            category = PortalCategory.NATIONAL_BANGLA,
            badgeText = "জাতীয় দৈনিক",
            accentHex = 0xFF37474F,
            defaultPinned = false
        ),

        // ================= NATIONAL ENGLISH NEWSPAPERS =================
        JobPrepPortal(
            id = "daily_star",
            nameBn = "দ্য ডেইলি স্টার (The Daily Star)",
            nameEn = "The Daily Star",
            subtitle = "বিসিএস ও ব্যাংক লিখিত পরীক্ষার অনুবাদ, ফোকাস রাইটিং ও ভোকাবুলারির প্রধান উৎস",
            url = "https://www.thedailystar.net",
            primaryDomain = "thedailystar.net",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "ইংরেজি দৈনিক",
            accentHex = 0xFF1E3A8A,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "daily_star_editorial",
            nameBn = "দ্য ডেইলি স্টার — Opinion & Editorial",
            nameEn = "Daily Star Editorial Section",
            subtitle = "সরাসরি সম্পাদকীয় ও মতামত পাতা (Written Focus Writing & Translation Practice)",
            url = "https://www.thedailystar.net/opinion",
            primaryDomain = "thedailystar.net",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "সম্পাদকীয় পাতা",
            accentHex = 0xFF0F172A,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "financial_express",
            nameBn = "দ্য ফিন্যান্সিয়াল এক্সপ্রেস (FE)",
            nameEn = "The Financial Express BD",
            subtitle = "ব্যাংক জব প্রিপারেশনের জন্য অপরিহার্য অর্থনৈতিক ও বাণিজ্যিক ইংরেজি দৈনিক",
            url = "https://thefinancialexpress.com.bd",
            primaryDomain = "thefinancialexpress.com.bd",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "ফিন্যান্স ও ব্যাংকিং",
            accentHex = 0xFF9A3412,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "tbs_news",
            nameBn = "দ্য বিজনেস স্ট্যান্ডার্ড (TBS)",
            nameEn = "The Business Standard",
            subtitle = "গভীর অর্থনৈতিক বিশ্লেষণ, ইনফোগ্রাফিক্স ও সমসাময়িক ব্যবসা-বাণিজ্য সংবাদ",
            url = "https://www.tbsnews.net",
            primaryDomain = "tbsnews.net",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "বিজনেস স্ট্যান্ডার্ড",
            accentHex = 0xFF065F46,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "dhaka_tribune",
            nameBn = "ঢাকা ট্রিবিউন (Dhaka Tribune)",
            nameEn = "Dhaka Tribune",
            subtitle = "জাতীয় ও আন্তর্জাতিক ইংরেজি সংবাদ, লং-ফর্ম আর্টিকেল ও মতামত",
            url = "https://www.dhakatribune.com",
            primaryDomain = "dhakatribune.com",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "ইংরেজি দৈনিক",
            accentHex = 0xFF312E81,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "new_age_bd",
            nameBn = "নিউ এজ (New Age Bangladesh)",
            nameEn = "New Age Daily",
            subtitle = "জাতীয় রাজনীতি, অর্থনীতি ও আন্তর্জাতিক বিষয়াবলীর ইংরেজি দৈনিক",
            url = "https://www.newagebd.net",
            primaryDomain = "newagebd.net",
            category = PortalCategory.NATIONAL_ENGLISH,
            badgeText = "ইংরেজি দৈনিক",
            accentHex = 0xFF4A148C,
            defaultPinned = false
        ),

        // ================= INTERNATIONAL NEWS & ECONOMY =================
        JobPrepPortal(
            id = "bbc_bengali",
            nameBn = "বিবিসি বাংলা (BBC News বাংলা)",
            nameEn = "BBC News Bengali",
            subtitle = "বিশ্ব রাজনীতি, দক্ষিণ এশিয়া ও আন্তর্জাতিক বিষয়াবলীর নির্ভরযোগ্য বাংলা বিশ্লেষণ",
            url = "https://www.bbc.com/bengali",
            primaryDomain = "bbc.com",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "আন্তর্জাতিক (বাংলা)",
            accentHex = 0xFF991B1B,
            defaultPinned = true
        ),
        JobPrepPortal(
            id = "bbc_world",
            nameBn = "বিবিসি ওয়ার্ল্ড নিউজ (BBC News)",
            nameEn = "BBC World News",
            subtitle = "আন্তর্জাতিক সাধারণ জ্ঞান, ভূ-রাজনীতি ও বিশ্ব অর্থনীতি (ইংরেজি)",
            url = "https://www.bbc.com/news",
            primaryDomain = "bbc.com",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "বিশ্ব সংবাদ",
            accentHex = 0xFF7F1D1D,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "reuters_global",
            nameBn = "রয়টার্স (Reuters International)",
            nameEn = "Reuters Global News",
            subtitle = "আন্তর্জাতিক কূটনীতি, বিশ্ব বাণিজ্য ও সাম্প্রতিক ঘটনাবলীর নিরপেক্ষ সংবাদ",
            url = "https://www.reuters.com",
            primaryDomain = "reuters.com",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "গ্লোবাল নিউজ",
            accentHex = 0xFFC2410C,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "aljazeera_english",
            nameBn = "আল জাজিরা (Al Jazeera English)",
            nameEn = "Al Jazeera International",
            subtitle = "মধ্যপ্রাচ্য, এশিয়া ও বৈশ্বিক ভূ-রাজনীতির গভীর বিশ্লেষণ ও ডকুমেন্টারি রিপোর্ট",
            url = "https://www.aljazeera.com",
            primaryDomain = "aljazeera.com",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "ভূ-রাজনীতি",
            accentHex = 0xFFB45309,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "the_economist",
            nameBn = "দ্য ইকোনমিস্ট (The Economist)",
            nameEn = "The Economist Global",
            subtitle = "বিশ্ব অর্থনীতি, কূটনীতি ও উচ্চতর ইংরেজি রিডিং কম্প্রিহেনশন অনুশীলন",
            url = "https://www.economist.com",
            primaryDomain = "economist.com",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "বিশ্ব অর্থনীতি",
            accentHex = 0xFFDC2626,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "project_syndicate",
            nameBn = "প্রজেক্ট সিন্ডিকেট (Project Syndicate)",
            nameEn = "Project Syndicate Commentaries",
            subtitle = "বিশ্বসেরা অর্থনীতিবিদ ও রাষ্ট্রবিজ্ঞানীদের বিশ্লেষণধর্মী প্রবন্ধ (Written Essay Prep)",
            url = "https://www.project-syndicate.org",
            primaryDomain = "project-syndicate.org",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "আন্তর্জাতিক কলাম",
            accentHex = 0xFF1E40AF,
            defaultPinned = false
        ),
        JobPrepPortal(
            id = "world_bank_bd",
            nameBn = "বিশ্বব্যাংক (World Bank Bangladesh)",
            nameEn = "World Bank Data & Reports",
            subtitle = "বাংলাদেশ ও বৈশ্বিক অর্থনৈতিক প্রবৃদ্ধি, উন্নয়ন প্রকল্প ও ডেটা রিপোর্ট",
            url = "https://www.worldbank.org/en/country/bangladesh",
            primaryDomain = "worldbank.org",
            category = PortalCategory.INTERNATIONAL_NEWS,
            badgeText = "উন্নয়ন ও ডেটা",
            accentHex = 0xFF0284C7,
            defaultPinned = false
        )
    )

    /**
     * Checks whether a given URL string is strictly permitted by the whitelist.
     * Supports wildcard matching for all subdomains of [approvedRootDomains], including
     * *.teletalk.com.bd, *.teletalk.bd, and *.gov.bd.
     */
    fun isUrlAllowed(urlString: String?): Boolean {
        if (urlString.isNullOrBlank()) return false
        val trimmed = urlString.trim()
        if (trimmed == "about:blank") return true
        // Allow blob: and data: schemes used by Teletalk & Bangladesh Bank for Admit Card PDF/image generation
        if (trimmed.startsWith("blob:") || trimmed.startsWith("data:")) return true

        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase() ?: return false
            if (scheme != "http" && scheme != "https") {
                return false
            }
            val host = uri.host?.lowercase()?.removePrefix("www.") ?: return false
            isDomainAllowed(host)
        } catch (e: Exception) {
            val extractedHost = extractHostFallback(trimmed) ?: return false
            isDomainAllowed(extractedHost)
        }
    }

    fun isDomainAllowed(rawHost: String): Boolean {
        val cleanHost = rawHost.trim().lowercase().removePrefix("www.")
        if (cleanHost.isEmpty()) return false

        return approvedRootDomains.any { approvedRoot ->
            val root = approvedRoot.lowercase().removePrefix("www.")
            cleanHost == root || cleanHost.endsWith(".$root")
        }
    }

    fun extractHostFallback(url: String): String? {
        val lower = url.trim().lowercase()
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return null
        val withoutScheme = lower.substringAfter("://")
        val authority = withoutScheme.substringBefore("/").substringBefore("?").substringBefore("#")
        val hostOnly = authority.substringBefore(":")
        return hostOnly.takeIf { it.isNotBlank() }
    }
}
