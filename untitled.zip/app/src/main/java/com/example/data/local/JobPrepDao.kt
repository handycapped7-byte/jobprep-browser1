package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface JobPrepDao {

    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllStudySessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM study_sessions WHERE dateKey = :dateKey")
    fun getTodayStudyMinutes(dateKey: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudySession(session: StudySessionEntity)

    @Query("SELECT * FROM favorite_portals WHERE isPinned = 1")
    fun getPinnedPortals(): Flow<List<FavoritePortalEntity>>

    @Query("SELECT COUNT(*) FROM favorite_portals")
    suspend fun getFavoritesEntryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFavorite(favorite: FavoritePortalEntity)

    @Query("SELECT * FROM blocked_attempts ORDER BY timestamp DESC LIMIT 30")
    fun getRecentBlockedAttempts(): Flow<List<BlockedAttemptEntity>>

    @Query("SELECT COUNT(*) FROM blocked_attempts")
    fun getTotalBlockedCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlockedAttempt(attempt: BlockedAttemptEntity)

    @Query("DELETE FROM blocked_attempts")
    suspend fun clearBlockedAttempts()

    @Query("SELECT * FROM daily_checklist WHERE dateKey = :dateKey ORDER BY id ASC")
    fun getChecklistForDate(dateKey: String): Flow<List<DailyChecklistEntity>>

    @Query("SELECT COUNT(*) FROM daily_checklist WHERE dateKey = :dateKey")
    suspend fun getChecklistCountForDate(dateKey: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecklistItem(item: DailyChecklistEntity)

    @Query("UPDATE daily_checklist SET isCompleted = :completed WHERE id = :id")
    suspend fun updateChecklistCompletion(id: Long, completed: Boolean)
}
