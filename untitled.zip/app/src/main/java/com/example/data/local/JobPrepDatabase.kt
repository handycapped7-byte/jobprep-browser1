package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        StudySessionEntity::class,
        FavoritePortalEntity::class,
        BlockedAttemptEntity::class,
        DailyChecklistEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class JobPrepDatabase : RoomDatabase() {
    abstract fun jobPrepDao(): JobPrepDao

    companion object {
        @Volatile
        private var INSTANCE: JobPrepDatabase? = null

        fun getInstance(context: Context): JobPrepDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JobPrepDatabase::class.java,
                    "jobprep_guard_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
