package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val portalId: String,
    val portalName: String,
    val categoryName: String,
    val durationMinutes: Int,
    val dateKey: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_portals")
data class FavoritePortalEntity(
    @PrimaryKey val portalId: String,
    val isPinned: Boolean,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "blocked_attempts")
data class BlockedAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val blockedUrl: String,
    val blockedDomain: String,
    val sourcePortalName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_checklist")
data class DailyChecklistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titleBn: String,
    val subtitleBn: String,
    val targetPortalId: String?,
    val isCompleted: Boolean = false,
    val dateKey: String
)
