package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import java.util.Locale

@Composable
fun PomodoroHeroBanner(
    todayStudyMinutes: Int,
    blockedCount: Int,
    totalAdsBlockedCount: Int,
    timerRemainingSeconds: Int,
    timerTotalSeconds: Int,
    isTimerRunning: Boolean,
    onToggleTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectPresetMinutes: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val progress by animateFloatAsState(
        targetValue = if (timerTotalSeconds > 0) {
            (timerTotalSeconds - timerRemainingSeconds).toFloat() / timerTotalSeconds.toFloat()
        } else 0f,
        label = "pomodoro_progress"
    )

    val mins = timerRemainingSeconds / 60
    val secs = timerRemainingSeconds % 60
    val formattedTime = String.format(Locale.US, "%02d:%02d", mins, secs)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pomodoro_hero_card"),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Generated Hero Background Art
            Image(
                painter = painterResource(id = R.drawable.img_study_hero_1794335409120),
                contentDescription = "Job Preparation Focus Desk Illustration",
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )

            // Deep Academic Emerald Gradient Overlay
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xD9042F1B),
                                Color(0xF2063B22),
                                Color(0xFA042817)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Top Strict Lockdown & Brave AdBlock Shield Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0x33D4A017),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x88F4C44E))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GppGood,
                                contentDescription = "Strict Whitelist Active",
                                tint = Color(0xFFF4C44E),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Strict Lockdown + Brave Shield",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFFFF8E1),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Ads & External Links Blocked Pill
                    Surface(
                        color = Color(0xFFFF5722).copy(alpha = 0.24f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF8A65))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Ads and Trackers Blocked",
                                tint = Color(0xFFFF8A65),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "অ্যাড ব্লকড: $totalAdsBlockedCount • সাইট: $blockedCount",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Main Study Stats & Pomodoro Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "ফোকাস স্টাডি টাইমার",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFB8E6CC)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.displaySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("pomodoro_time_text")
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "আজ পড়া হয়েছে: ${todayStudyMinutes} মি.",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFFF4C44E),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }

                    // Play / Pause & Reset Controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleTimer,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTimerRunning) Color(0xFFD4A017) else Color(0xFF22C55E),
                                contentColor = Color(0xFF042817)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("pomodoro_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isTimerRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isTimerRunning) "Pause Timer" else "Start Timer",
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isTimerRunning) "বিরতি" else "শুরু",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        FilledTonalIconButton(
                            onClick = onResetTimer,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.16f),
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("pomodoro_reset_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset Timer"
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Progress & Preset Chips Row
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = Color(0xFFF4C44E),
                    trackColor = Color.White.copy(alpha = 0.2f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = Color(0xFFB8E6CC),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "সেশন:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFB8E6CC)
                    )
                    listOf(25 to "২৫ মিনিট (Pomodoro)", 50 to "৫০ মিনিট (Deep Study)").forEach { (minsPreset, label) ->
                        val isSelected = (timerTotalSeconds / 60) == minsPreset
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectPresetMinutes(minsPreset) },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFF4C44E),
                                selectedLabelColor = Color(0xFF042817),
                                containerColor = Color.White.copy(alpha = 0.1f),
                                labelColor = Color.White
                            ),
                            border = null
                        )
                    }
                }
            }
        }
    }
}
