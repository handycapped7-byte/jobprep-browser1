package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.AdBlockerEngine
import com.example.data.JobPrepPortal
import com.example.data.WhitelistRegistry
import com.example.viewmodel.BlockedNotice
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * Helper JavascriptInterface to support downloading blob: or base64 Admit Card PDFs
 * generated dynamically on Teletalk and Bangladesh Bank portals.
 */
private class AdmitCardBlobDownloader(private val context: Context) {
    @JavascriptInterface
    fun saveBase64File(base64Data: String, mimeType: String, fileName: String) {
        try {
            val cleanBase64 = base64Data.substringAfter("base64,")
            val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val safeName = fileName.ifBlank { "AdmitCard_${System.currentTimeMillis()}.pdf" }
            val outFile = File(downloadsDir, safeName)
            FileOutputStream(outFile).use { it.write(bytes) }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "প্রবেশপত্র সেভ হয়েছে: Downloads/$safeName",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (e: Exception) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "প্রবেশপত্র সংরক্ষণে ত্রুটি: উপরের বা নিচের PDF বাটনটি ব্যবহার করুন",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}

/**
 * Triggers Android's native Print-to-PDF dialog so the user can save any Admit Card,
 * Applicant's Copy, or Job Circular page directly as a PDF file.
 */
private fun exportCurrentPageAsAdmitCardPdf(context: Context, webView: WebView, title: String) {
    try {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager != null) {
            val cleanTitle = title.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(30).ifBlank { "Admit_Card" }
            val jobName = "JobPrep_${cleanTitle}_${System.currentTimeMillis() / 1000}"
            val printAdapter = webView.createPrintDocumentAdapter(jobName)
            printManager.print(
                jobName,
                printAdapter,
                PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .build()
            )
        }
    } catch (e: Exception) {
        Toast.makeText(context, "PDF প্রিন্ট চালু করা যায়নি", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SafeLockdownBrowserScreen(
    portal: JobPrepPortal,
    browsingSeconds: Int,
    isPomodoroRunning: Boolean,
    pomodoroRemainingSeconds: Int,
    isDarkMode: Boolean,
    isAdBlockEnabled: Boolean,
    pageAdsBlockedCount: Int,
    totalAdsBlockedCount: Int,
    blockedNotice: BlockedNotice?,
    onToggleDarkMode: () -> Unit,
    onToggleAdBlock: (Boolean) -> Unit,
    onAdBlocked: () -> Unit,
    onBlockedUrl: (String) -> Unit,
    onDismissBlockedNotice: () -> Unit,
    onSwitchPortal: (JobPrepPortal) -> Unit,
    onCloseBrowser: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var currentUrl by remember(portal.id) { mutableStateOf(portal.url) }
    var pageTitle by remember(portal.id) { mutableStateOf(portal.nameBn) }
    var loadProgress by remember { mutableIntStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var showQuickSwitchSheet by remember { mutableStateOf(false) }
    var showBraveShieldDialog by remember { mutableStateOf(false) }

    val adBlockEnabledState by rememberUpdatedState(isAdBlockEnabled)
    val onAdBlockedCallback by rememberUpdatedState(onAdBlocked)

    val webView = remember {
        WebView(context).apply {
            // Enable First-Party & Third-Party Cookies so YouTube Google Sign-In and Teletalk Sessions work
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            cookieManager.setAcceptThirdPartyCookies(this, true)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadsImagesAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = true
                displayZoomControls = false
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = true
                allowContentAccess = true

                // Strip "; wv" from WebView User-Agent so Google Sign-In (accounts.google.com) on YouTube
                // does not reject the login with 403 disallowed_useragent
                val defaultUa = userAgentString ?: ""
                userAgentString = defaultUa
                    .replace("; wv)", ")")
                    .replace("Version/4.0 ", "")
            }

            addJavascriptInterface(AdmitCardBlobDownloader(context), "JobPrepDownloader")

            // Full Admit Card, Circular & PDF Download Listener with Session Cookies
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                if (url.isNullOrBlank()) return@setDownloadListener

                // 1. Handle blob: URLs by converting them to Base64 in JS and saving to Downloads
                if (url.startsWith("blob:")) {
                    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType.ifBlank { "application/pdf" })
                    val blobJs = """
                        (function() {
                            fetch('$url')
                                .then(r => r.blob())
                                .then(blob => {
                                    var reader = new FileReader();
                                    reader.onloadend = function() {
                                        window.JobPrepDownloader.saveBase64File(reader.result, '${mimeType}', '$fileName');
                                    };
                                    reader.readAsDataURL(blob);
                                });
                        })();
                    """.trimIndent()
                    evaluateJavascript(blobJs, null)
                    return@setDownloadListener
                }

                // 2. Handle data: base64 URLs
                if (url.startsWith("data:")) {
                    val fileName = "AdmitCard_${System.currentTimeMillis()}.pdf"
                    AdmitCardBlobDownloader(context).saveBase64File(url, mimeType, fileName)
                    return@setDownloadListener
                }

                // 3. Handle standard HTTP/HTTPS Admit Card & Circular PDF/Image Downloads via DownloadManager
                try {
                    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimeType)
                        // Pass active session cookies (essential for Teletalk & Bangladesh Bank Admit Cards!)
                        val cookies = CookieManager.getInstance().getCookie(url)
                        if (!cookies.isNullOrBlank()) {
                            addRequestHeader("Cookie", cookies)
                        }
                        if (!userAgent.isNullOrBlank()) {
                            addRequestHeader("User-Agent", userAgent)
                        }
                        addRequestHeader("Referer", currentUrl)
                        setDescription("JobPrep Guard: প্রবেশপত্র / সার্কুলার ডাউনলোড হচ্ছে...")
                        setTitle(fileName)
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    }
                    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(request)
                    Toast.makeText(
                        context,
                        "ডাউনলোড শুরু হয়েছে: $fileName (Downloads ফোল্ডারে দেখুন)",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (e: Exception) {
                    // Fallback: export current page as PDF via PrintManager
                    exportCurrentPageAsAdmitCardPdf(context, this, pageTitle)
                }
            }
        }
    }

    // Apply subtle dark reading mode CSS filter when dark mode is toggled
    LaunchedEffect(isDarkMode, currentUrl) {
        val darkJs = if (isDarkMode) {
            """
            (function() {
                document.documentElement.style.setProperty('color-scheme', 'dark');
            })();
            """.trimIndent()
        } else {
            """
            (function() {
                document.documentElement.style.setProperty('color-scheme', 'light');
            })();
            """.trimIndent()
        }
        webView.evaluateJavascript(darkJs, null)
    }

    DisposableEffect(portal.id) {
        webView.webViewClient = object : WebViewClient() {

            // Layer 1: Brave-Style Network Request Ad & Tracker Interception
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val reqUrl = request?.url?.toString() ?: return null

                if (adBlockEnabledState && AdBlockerEngine.isAdOrTrackerRequest(reqUrl)) {
                    onAdBlockedCallback()
                    return AdBlockerEngine.createEmptyResourceResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val targetUrl = request?.url?.toString() ?: return true
                if (targetUrl.startsWith("jobprep://print-pdf")) {
                    if (view != null) {
                        exportCurrentPageAsAdmitCardPdf(context, view, pageTitle)
                    }
                    return true
                }
                if (adBlockEnabledState && AdBlockerEngine.isAdOrTrackerRequest(targetUrl)) {
                    onAdBlockedCallback()
                    return true
                }
                return if (WhitelistRegistry.isUrlAllowed(targetUrl)) {
                    currentUrl = targetUrl
                    false
                } else {
                    onBlockedUrl(targetUrl)
                    true
                }
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val targetUrl = url ?: return true
                if (targetUrl.startsWith("jobprep://print-pdf")) {
                    if (view != null) {
                        exportCurrentPageAsAdmitCardPdf(context, view, pageTitle)
                    }
                    return true
                }
                if (adBlockEnabledState && AdBlockerEngine.isAdOrTrackerRequest(targetUrl)) {
                    onAdBlockedCallback()
                    return true
                }
                return if (WhitelistRegistry.isUrlAllowed(targetUrl)) {
                    currentUrl = targetUrl
                    false
                } else {
                    onBlockedUrl(targetUrl)
                    true
                }
            }

            // Allow government & Teletalk portals whose SSL certificates may be self-signed/legacy
            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                val errorUrl = error?.url ?: ""
                if (WhitelistRegistry.isUrlAllowed(errorUrl)) {
                    handler?.proceed()
                } else {
                    handler?.cancel()
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                val targetUrl = url ?: return
                if (!WhitelistRegistry.isUrlAllowed(targetUrl)) {
                    view?.stopLoading()
                    onBlockedUrl(targetUrl)
                    return
                }
                currentUrl = targetUrl
                canGoBack = view?.canGoBack() == true
                canGoForward = view?.canGoForward() == true

                if (adBlockEnabledState) {
                    view?.evaluateJavascript(AdBlockerEngine.cosmeticAdBlockJavaScript, null)
                }
            }

            override fun onLoadResource(view: WebView?, url: String?) {
                super.onLoadResource(view, url)
                if (adBlockEnabledState) {
                    view?.evaluateJavascript(AdBlockerEngine.cosmeticAdBlockJavaScript, null)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                canGoBack = view?.canGoBack() == true
                canGoForward = view?.canGoForward() == true
                if (!view?.title.isNullOrBlank()) {
                    pageTitle = view?.title ?: portal.nameBn
                }
                if (adBlockEnabledState) {
                    view?.evaluateJavascript(AdBlockerEngine.cosmeticAdBlockJavaScript, null)
                }
                // Hook window.print() so clicking "Print Admit Card" on Teletalk/Bank websites
                // opens the Android PDF saver dialog!
                val hookPrintJs = """
                    (function() {
                        window.print = function() {
                            window.location.href = 'jobprep://print-pdf';
                        };
                    })();
                """.trimIndent()
                view?.evaluateJavascript(hookPrintJs, null)
                CookieManager.getInstance().flush()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                loadProgress = newProgress
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) {
                    pageTitle = title
                }
            }
        }

        webView.loadUrl(portal.url)

        onDispose {
            CookieManager.getInstance().flush()
            webView.stopLoading()
        }
    }

    BackHandler {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            onCloseBrowser()
        }
    }

    val currentHost = remember(currentUrl) {
        WhitelistRegistry.extractHostFallback(currentUrl) ?: portal.primaryDomain
    }

    val studyMins = browsingSeconds / 60
    val studySecs = browsingSeconds % 60
    val studyTimeFormatted = String.format(Locale.US, "%02d:%02d", studyMins, studySecs)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("safe_lockdown_browser")
    ) {
        // 1. Top Verified Security & Brave Shield Header Bar (NO Editable Address Bar!)
        Surface(
            color = Color(0xFF063B22),
            contentColor = Color.White,
            shadowElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Close to Hub Button
                    IconButton(
                        onClick = onCloseBrowser,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("browser_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Browser and Return to Hub",
                            tint = Color.White
                        )
                    }

                    // Verified Domain Pill (Read-Only)
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GppGood,
                                contentDescription = "Verified Whitelisted Domain",
                                tint = Color(0xFF66DBA0),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = currentHost,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFF66DBA0),
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.testTag("browser_verified_host")
                            )
                        }

                        Text(
                            text = pageTitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Brave-Style Shield Button (Shows Live Ads Blocked on Page)
                    Surface(
                        color = if (isAdBlockEnabled) Color(0xFFFF5722).copy(alpha = 0.22f) else Color.White.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isAdBlockEnabled) Color(0xFFFF8A65) else Color.White.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clickable { showBraveShieldDialog = true }
                            .testTag("brave_shield_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Brave Style AdBlock Shield",
                                tint = if (isAdBlockEnabled) Color(0xFFFF8A65) else Color.LightGray,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (isAdBlockEnabled) "$pageAdsBlockedCount" else "OFF",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Active Study Session Counter Pill
                    Surface(
                        color = Color(0x33D4A017),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x88F4C44E))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Session Study Time",
                                tint = Color(0xFFF4C44E),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (isPomodoroRunning) {
                                    val pM = pomodoroRemainingSeconds / 60
                                    val pS = pomodoroRemainingSeconds % 60
                                    String.format(Locale.US, "%02d:%02d", pM, pS)
                                } else {
                                    studyTimeFormatted
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Loading Progress Bar
                AnimatedVisibility(visible = loadProgress in 1..99) {
                    LinearProgressIndicator(
                        progress = { loadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = Color(0xFFF4C44E),
                        trackColor = Color.Transparent
                    )
                }
            }
        }

        // 2. WebView Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            AndroidView(
                factory = { webView },
                modifier = Modifier.fillMaxSize()
            )
        }

        // 3. Bottom Safe Navigation, Admit Card PDF Saver & Theme Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (webView.canGoBack()) webView.goBack() },
                    enabled = canGoBack,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Navigate Back"
                    )
                }

                IconButton(
                    onClick = { if (webView.canGoForward()) webView.goForward() },
                    enabled = canGoForward,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Navigate Forward"
                    )
                }

                IconButton(
                    onClick = { webView.loadUrl(portal.url) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Portal Home Page"
                    )
                }

                IconButton(
                    onClick = { webView.reload() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reload Page"
                    )
                }

                // Save Admit Card / Page as PDF Button
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .clickable {
                            exportCurrentPageAsAdmitCardPdf(context, webView, pageTitle)
                        }
                        .testTag("save_admit_card_pdf_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Save Admit Card or Page as PDF",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "PDF সেভ",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Light / Dark Mode Theme Toggle Button
                IconButton(
                    onClick = onToggleDarkMode,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("browser_theme_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode",
                        tint = if (isDarkMode) Color(0xFFF4C44E) else MaterialTheme.colorScheme.onSurface
                    )
                }

                // Quick Switch Portal Button
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .clickable { showQuickSwitchSheet = true }
                        .testTag("browser_quick_switch_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Quick Switch Portal",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "পোর্টাল",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // 4. Brave-Style AdBlocker Shield Dialog
    if (showBraveShieldDialog) {
        AlertDialog(
            onDismissRequest = { showBraveShieldDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            if (isAdBlockEnabled) Color(0xFFFF5722).copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Brave AdBlock Shield",
                        tint = if (isAdBlockEnabled) Color(0xFFFF5722) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(32.dp)
                    )
                }
            },
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Brave-Style AdBlock Shield",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = currentHost,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isAdBlockEnabled) "Shields UP (সক্রিয়)" else "Shields DOWN (বন্ধ)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "বিজ্ঞাপন, ট্র্যাকার ও পপ-আপ ব্লকার",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = isAdBlockEnabled,
                                onCheckedChange = { enabled ->
                                    onToggleAdBlock(enabled)
                                    webView.reload()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFFF5722)
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$pageAdsBlockedCount",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "এই পেজে ব্লকড",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "$totalAdsBlockedCount",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "সর্বমোট অ্যাড ব্লকড",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "নেটওয়ার্ক লেভেল অ্যাড ও ট্র্যাকার ব্লকিং (AdSense, DoubleClick, Eskimi)",
                            "পত্রিকার ফাঁকা বিজ্ঞাপনের বক্স ও ব্যানার রিমুভার (Cosmetic CSS Filter)",
                            "ইউটিউব ভিডিও অ্যাড অটো-স্কিপার ও গুগল সাইন-ইন সাপোর্ট",
                            "টেলিটক ও বাংলাদেশ ব্যাংক প্রবেশপত্র (Admit Card) সরাসরি ডাউনলোড"
                        ).forEach { feature ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = feature,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showBraveShieldDialog = false }) {
                    Text("ঠিক আছে")
                }
            }
        )
    }

    // 5. Quick Switch Portal Bottom Sheet
    if (showQuickSwitchSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQuickSwitchSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "দ্রুত অন্য অনুমোদিত পোর্টালে যান",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ব্রাউজার না ছেড়েই যেকোনো টেলিটক বিভাগ (★.teletalk.com.bd) বা অন্য পোর্টালে সুইচ করুন",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                com.example.ui.components.TeletalkSubdomainLauncherCard(
                    onLaunchTeletalkPortal = { customPortal ->
                        showQuickSwitchSheet = false
                        onSwitchPortal(customPortal)
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(320.dp)
                ) {
                    items(WhitelistRegistry.portals, key = { "switch_${it.id}" }) { item ->
                        val isCurrent = item.id == portal.id
                        Surface(
                            color = if (isCurrent) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showQuickSwitchSheet = false
                                    if (!isCurrent) {
                                        onSwitchPortal(item)
                                    }
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(item.accentHex)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = categoryIcon(item.category),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.nameBn,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = item.primaryDomain,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (isCurrent) {
                                    Text(
                                        text = "চলমান",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 6. Blocked External Link Alert Modal
    if (blockedNotice != null) {
        AlertDialog(
            onDismissRequest = onDismissBlockedNotice,
            icon = {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.errorContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = "Blocked Website",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(32.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "অ্যাক্সেস সীমাবদ্ধ (Access Restricted)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "এই লিংকটি আপনার জব প্রিপারেশন হোয়াইটলিস্টের অন্তর্ভুক্ত নয়। মনোযোগ ধরে রাখতে বাহ্যিক ওয়েবসাইট ও সোশ্যাল মিডিয়া সম্পূর্ণ ব্লক করা হয়েছে।",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "ব্লক করা ডোমেইন: ${blockedNotice.blockedDomain}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = blockedNotice.blockedUrl,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onDismissBlockedNotice,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("dismiss_blocked_dialog_button")
                ) {
                    Text("নিরাপদ পেজে ফিরে যান")
                }
            }
        )
    }
}
