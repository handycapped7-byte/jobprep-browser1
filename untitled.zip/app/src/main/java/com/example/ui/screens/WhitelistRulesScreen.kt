package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.AdBlockerEngine
import com.example.data.WhitelistRegistry
import com.example.data.local.BlockedAttemptEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WhitelistRulesScreen(
    isAdBlockEnabled: Boolean,
    totalAdsBlockedCount: Int,
    recentBlockedAttempts: List<BlockedAttemptEntity>,
    totalBlockedCount: Int,
    onToggleAdBlock: (Boolean) -> Unit,
    onClearBlockedHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var testUrlInput by remember { mutableStateOf("https://www.facebook.com") }
    val isTestUrlAllowed = remember(testUrlInput) {
        WhitelistRegistry.isUrlAllowed(testUrlInput)
    }
    val isTestUrlAd = remember(testUrlInput) {
        AdBlockerEngine.isAdOrTrackerRequest(testUrlInput)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("whitelist_rules_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Brave-Style AdBlocker Shield Control Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("brave_shield_settings_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1E1B18),
                    contentColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF5722).copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = Color(0xFFFF7043),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Brave-Style AdBlock Shield",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "সর্বমোট ব্লক করা বিজ্ঞাপন ও ট্র্যাকার: $totalAdsBlockedCount",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFFAB91)
                                )
                            }
                        }

                        Switch(
                            checked = isAdBlockEnabled,
                            onCheckedChange = onToggleAdBlock,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFFFF5722)
                            )
                        )
                    }

                    Text(
                        text = "• নেটওয়ার্ক লেভেলে Google AdSense, DoubleClick, Taboola, Outbrain এবং বাংলাদেশি পত্রিকার অ্যাড সার্ভার (Eskimi, PurplePatch) ডাউনলোডের আগেই ব্লক করে।\n" +
                            "• পত্রিকার পাতায় বিজ্ঞাপনের ফাঁকা বক্স ও স্টিকি ব্যানার স্বয়ংক্রিয়ভাবে লুকিয়ে ফেলে (Cosmetic Filtering)।\n" +
                            "• ইউটিউব ভিডিওর বিজ্ঞাপন অটো-স্কিপ এবং ফিডের স্পনসরড অ্যাড রিমুভ করে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.88f)
                    )
                }
            }
        }

        // 2. Strict Lockdown Status Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF063B22),
                    contentColor = Color.White
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF22C55E).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Color(0xFF66DBA0),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Strict Whitelist Lockdown সক্রিয়",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "অনুমোদিত ডোমেইন ব্যতীত অন্য সব সাইট শতভাগ ব্লকড",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFB8E6CC)
                            )
                        }
                    }

                    Text(
                        text = "• কোনো অ্যাড্রেস বার (URL Bar) নেই, তাই ইচ্ছেমতো ওয়েবসাইট টাইপ করে ঢোকা অসম্ভব।\n" +
                            "• পত্রিকার ভেতরে থাকা সোশ্যাল মিডিয়া শেয়ার বাটন (Facebook, X, Instagram, TikTok) বা বাহ্যিক লিংকে ক্লিক করলেও অ্যাপ সাথে সাথে তা ব্লক করে দেবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        // 3. Interactive Whitelist & AdBlock Security Verifier
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "হোয়াইটলিস্ট ও অ্যাড-ব্লকার পরীক্ষক (Test Filter)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "যেকোনো লিংক বা অ্যাড সার্ভার নিচের বক্সে দিয়ে যাচাই করুন:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = testUrlInput,
                        onValueChange = { testUrlInput = it },
                        label = { Text("টেস্ট URL") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("firewall_test_input")
                    )

                    // Quick sample URL pills
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "http://dcd.teletalk.com.bd",
                            "http://bogmc.teletalk.bd",
                            "https://alljobs.teletalk.com.bd",
                            "https://www.facebook.com",
                            "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
                        ).forEach { sample ->
                            FilledTonalButton(
                                onClick = { testUrlInput = sample },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text(
                                    text = sample.removePrefix("https://").removePrefix("www.").take(22),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    val allowedAndClean = isTestUrlAllowed && !isTestUrlAd
                    Surface(
                        color = if (allowedAndClean) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.errorContainer
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("firewall_test_result")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = if (allowedAndClean) Icons.Default.CheckCircle else Icons.Default.Block,
                                contentDescription = null,
                                tint = if (allowedAndClean) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                            Column {
                                Text(
                                    text = when {
                                        isTestUrlAd -> "অ্যাড ও ট্র্যাকার ব্লকড (BLOCKED BY BRAVE SHIELD)"
                                        isTestUrlAllowed -> "অনুমোদিত ও নিরাপদ (ALLOWED IN BROWSER)"
                                        else -> "সম্পূর্ণ নিষিদ্ধ ও ব্লকড (STRICTLY BLOCKED)"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (allowedAndClean) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.error
                                    }
                                )
                                Text(
                                    text = when {
                                        isTestUrlAd -> "এই লিংকটি একটি বিজ্ঞাপন/ট্র্যাকার সার্ভার; Brave Shield এটি লোড হওয়ার আগেই ব্লক করবে।"
                                        isTestUrlAllowed -> "এই সাইটটি জব প্রিপারেশন হোয়াইটলিস্টের অন্তর্ভুক্ত।"
                                        else -> "এই সাইটে প্রবেশ করা অসম্ভব; ক্লিক করলেই ফায়ারওয়াল আটকে দেবে।"
                                    },
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Approved Root Domains List
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "অনুমোদিত রুট ডোমেইন তালিকা (${WhitelistRegistry.approvedRootDomains.size}টি)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WhitelistRegistry.approvedRootDomains.forEach { domain ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GppGood,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = domain,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. Blocked External Attempts Log
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ব্লক করা বাহ্যিক লিংকের তালিকা ($totalBlockedCount)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (recentBlockedAttempts.isNotEmpty()) {
                    TextButton(onClick = onClearBlockedHistory) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("মুছে ফেলুন")
                    }
                }
            }
        }

        if (recentBlockedAttempts.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "এখন পর্যন্ত কোনো অননুমোদিত লিংকে ক্লিক করা হয়নি।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(recentBlockedAttempts, key = { "blocked_${it.id}" }) { attempt ->
                val formattedTime = remember(attempt.timestamp) {
                    SimpleDateFormat("hh:mm a, dd MMM", Locale.US).format(Date(attempt.timestamp))
                }
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = attempt.blockedDomain,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = attempt.blockedUrl,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "উৎস: ${attempt.sourcePortalName} • $formattedTime",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
