package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Academic Emerald & Warm Gold Palette for Focused Job Preparation
val EmeraldPrimary = Color(0xFF0A5C36)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD2F5E0)
val EmeraldOnPrimaryContainer = Color(0xFF03301A)

val GoldSecondary = Color(0xFFB8860B)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldSecondaryContainer = Color(0xFFFFF0C2)
val GoldOnSecondaryContainer = Color(0xFF3A2800)

val TealTertiary = Color(0xFF0F5257)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealTertiaryContainer = Color(0xFFC7F2F5)
val TealOnTertiaryContainer = Color(0xFF002022)

val LightBackground = Color(0xFFF6F9F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7EFE9)
val LightOnSurface = Color(0xFF141D18)
val LightOnSurfaceVariant = Color(0xFF425248)

val DarkPrimary = Color(0xFF66DBA0)
val DarkOnPrimary = Color(0xFF00381D)
val DarkPrimaryContainer = Color(0xFF074B2B)
val DarkOnPrimaryContainer = Color(0xFFD2F5E0)

val DarkSecondary = Color(0xFFF4C44E)
val DarkOnSecondary = Color(0xFF422D00)
val DarkSecondaryContainer = Color(0xFF5E4200)
val DarkOnSecondaryContainer = Color(0xFFFFF0C2)

val DarkBackground = Color(0xFF0F1511)
val DarkSurface = Color(0xFF17201A)
val DarkSurfaceVariant = Color(0xFF233028)
val DarkOnSurface = Color(0xFFE3ECE6)
val DarkOnSurfaceVariant = Color(0xFF9EB0A5)

val DangerRed = Color(0xFFC8372D)
val DangerRedContainer = Color(0xFFFFDAD6)
val YouTubeRed = Color(0xFFD32F2F)
