package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.JobPrepPortal
import com.example.data.JobPrepRepository
import com.example.data.PortalCategory
import com.example.data.WhitelistRegistry
import com.example.data.local.BlockedAttemptEntity
import com.example.data.local.DailyChecklistEntity
import com.example.data.local.StudySessionEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class BlockedNotice(
    val blockedUrl: String,
    val blockedDomain: String,
    val sourcePortalName: String
)

enum class MainTab {
    PORTALS,
    STUDY_TRACKER,
    WHITELIST_GUARD
}

class JobPrepViewModel(
    private val repository: JobPrepRepository
) : ViewModel() {

    private val _currentTab = MutableStateFlow(MainTab.PORTALS)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow(PortalCategory.ALL)
    val selectedCategory: StateFlow<PortalCategory> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activePortal = MutableStateFlow<JobPrepPortal?>(null)
    val activePortal: StateFlow<JobPrepPortal?> = _activePortal.asStateFlow()

    private val _blockedNotice = MutableStateFlow<BlockedNotice?>(null)
    val blockedNotice: StateFlow<BlockedNotice?> = _blockedNotice.asStateFlow()

    // Global Light / Dark Theme State for Late-Night Study Sessions
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Brave-Style Ad & Tracker Shield State
    private val _isAdBlockEnabled = MutableStateFlow(true)
    val isAdBlockEnabled: StateFlow<Boolean> = _isAdBlockEnabled.asStateFlow()

    private val _pageAdsBlockedCount = MutableStateFlow(0)
    val pageAdsBlockedCount: StateFlow<Int> = _pageAdsBlockedCount.asStateFlow()

    private val _totalAdsBlockedCount = MutableStateFlow(0)
    val totalAdsBlockedCount: StateFlow<Int> = _totalAdsBlockedCount.asStateFlow()

    // Pomodoro Focus Timer State
    private val _timerTotalSeconds = MutableStateFlow(25 * 60)
    val timerTotalSeconds: StateFlow<Int> = _timerTotalSeconds.asStateFlow()

    private val _timerRemainingSeconds = MutableStateFlow(25 * 60)
    val timerRemainingSeconds: StateFlow<Int> = _timerRemainingSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _completedPomodoros = MutableStateFlow(0)
    val completedPomodoros: StateFlow<Int> = _completedPomodoros.asStateFlow()

    // Active Browsing Session Counter (seconds spent in current WebView session)
    private val _browsingSeconds = MutableStateFlow(0)
    val browsingSeconds: StateFlow<Int> = _browsingSeconds.asStateFlow()

    private var timerJob: Job? = null
    private var browsingSessionJob: Job? = null

    val pinnedPortalIds: StateFlow<Set<String>> = repository.pinnedPortalsFlow
        .combine(MutableStateFlow(Unit)) { list, _ ->
            list.filter { it.isPinned }.map { it.portalId }.toSet()
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = WhitelistRegistry.portals.filter { it.defaultPinned }.map { it.id }.toSet()
        )

    val filteredPortals: StateFlow<List<JobPrepPortal>> = combine(
        _selectedCategory,
        _searchQuery
    ) { category, query ->
        val trimmed = query.trim().lowercase()
        WhitelistRegistry.portals.filter { portal ->
            val matchesCategory = category == PortalCategory.ALL || portal.category == category
            val matchesSearch = trimmed.isEmpty() ||
                portal.nameBn.lowercase().contains(trimmed) ||
                portal.nameEn.lowercase().contains(trimmed) ||
                portal.subtitle.lowercase().contains(trimmed) ||
                portal.primaryDomain.lowercase().contains(trimmed) ||
                portal.badgeText.lowercase().contains(trimmed)
            matchesCategory && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WhitelistRegistry.portals
    )

    val todayStudyMinutes: StateFlow<Int> = repository.getTodayStudyMinutes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val allStudySessions: StateFlow<List<StudySessionEntity>> = repository.allStudySessions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val todayChecklist: StateFlow<List<DailyChecklistEntity>> = repository.getTodayChecklist()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentBlockedAttempts: StateFlow<List<BlockedAttemptEntity>> = repository.recentBlockedAttempts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val totalBlockedCount: StateFlow<Int> = repository.totalBlockedCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    init {
        viewModelScope.launch {
            repository.ensureDefaultsInitialized()
        }
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun selectCategory(category: PortalCategory) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun togglePin(portalId: String) {
        val currentlyPinned = pinnedPortalIds.value.contains(portalId)
        viewModelScope.launch {
            repository.togglePinPortal(portalId, currentlyPinned)
        }
    }

    fun openPortal(portal: JobPrepPortal) {
        flushActiveBrowsingSession()
        _pageAdsBlockedCount.value = 0
        _activePortal.value = portal
        startBrowsingTicker()
    }

    fun openPortalById(portalId: String) {
        val found = WhitelistRegistry.portals.find { it.id == portalId }
        if (found != null) {
            openPortal(found)
        }
    }

    fun closeBrowser() {
        flushActiveBrowsingSession()
        _activePortal.value = null
    }

    // ================= THEME & LATE-NIGHT STUDY MODE CONTROLS =================
    fun setInitialDarkMode(dark: Boolean) {
        _isDarkMode.value = dark
    }

    fun toggleDarkMode() {
        _isDarkMode.update { !it }
    }

    // ================= BRAVE-STYLE AD BLOCKER CONTROLS =================
    fun toggleAdBlocker(enabled: Boolean) {
        _isAdBlockEnabled.value = enabled
    }

    /**
     * Thread-safe increment called from WebView's background shouldInterceptRequest thread.
     */
    fun onAdOrTrackerBlocked() {
        _pageAdsBlockedCount.update { it + 1 }
        _totalAdsBlockedCount.update { it + 1 }
    }

    fun resetPageAdCount() {
        _pageAdsBlockedCount.value = 0
    }

    private fun startBrowsingTicker() {
        browsingSessionJob?.cancel()
        _browsingSeconds.value = 0
        browsingSessionJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                _browsingSeconds.value += 1
            }
        }
    }

    private fun flushActiveBrowsingSession() {
        browsingSessionJob?.cancel()
        browsingSessionJob = null
        val portal = _activePortal.value
        val elapsedSec = _browsingSeconds.value
        _browsingSeconds.value = 0
        if (portal != null && elapsedSec >= 15) {
            val minutes = (elapsedSec / 60).coerceAtLeast(1)
            viewModelScope.launch {
                repository.logStudySession(portal, minutes)
            }
        }
    }

    fun onExternalUrlBlocked(blockedUrl: String, sourcePortal: JobPrepPortal) {
        val host = WhitelistRegistry.extractHostFallback(blockedUrl) ?: blockedUrl.take(40)
        _blockedNotice.value = BlockedNotice(
            blockedUrl = blockedUrl,
            blockedDomain = host,
            sourcePortalName = sourcePortal.nameBn
        )
        viewModelScope.launch {
            repository.logBlockedUrl(
                blockedUrl = blockedUrl,
                blockedDomain = host,
                sourcePortalName = sourcePortal.nameBn
            )
        }
    }

    fun dismissBlockedNotice() {
        _blockedNotice.value = null
    }

    fun clearBlockedHistory() {
        viewModelScope.launch {
            repository.clearBlockedHistory()
        }
    }

    // ================= POMODORO FOCUS TIMER =================
    fun setPomodoroPreset(minutes: Int) {
        timerJob?.cancel()
        _isTimerRunning.value = false
        val seconds = minutes * 60
        _timerTotalSeconds.value = seconds
        _timerRemainingSeconds.value = seconds
    }

    fun togglePomodoroTimer() {
        if (_isTimerRunning.value) {
            pausePomodoroTimer()
        } else {
            startPomodoroTimer()
        }
    }

    private fun startPomodoroTimer() {
        if (_isTimerRunning.value) return
        _isTimerRunning.value = true
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive && _timerRemainingSeconds.value > 0) {
                delay(1000L)
                _timerRemainingSeconds.value -= 1
            }
            if (_timerRemainingSeconds.value == 0) {
                _isTimerRunning.value = false
                _completedPomodoros.value += 1
                val presetMinutes = _timerTotalSeconds.value / 60
                val fallbackPortal = _activePortal.value ?: WhitelistRegistry.portals.first()
                repository.logStudySession(fallbackPortal, presetMinutes)
                _timerRemainingSeconds.value = _timerTotalSeconds.value
            }
        }
    }

    private fun pausePomodoroTimer() {
        timerJob?.cancel()
        _isTimerRunning.value = false
    }

    fun resetPomodoroTimer() {
        timerJob?.cancel()
        _isTimerRunning.value = false
        _timerRemainingSeconds.value = _timerTotalSeconds.value
    }

    // ================= DAILY CHECKLIST =================
    fun toggleChecklistItem(item: DailyChecklistEntity) {
        viewModelScope.launch {
            repository.toggleChecklistTask(item.id, !item.isCompleted)
        }
    }

    fun addCustomChecklistTask(titleBn: String, subtitleBn: String, targetPortalId: String?) {
        if (titleBn.isBlank()) return
        viewModelScope.launch {
            repository.addCustomChecklistTask(
                titleBn = titleBn.trim(),
                subtitleBn = subtitleBn.trim().ifEmpty { "দৈনিক প্রস্তুতির লক্ষ্যমাত্রা" },
                targetPortalId = targetPortalId
            )
        }
    }

    class Factory(private val repository: JobPrepRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return JobPrepViewModel(repository) as T
        }
    }
}
