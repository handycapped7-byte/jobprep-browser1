package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.WhitelistRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context and verify whitelist`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JobPrep Guard", appName)
        assertTrue(WhitelistRegistry.isUrlAllowed("https://m.youtube.com"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://erecruitment.bb.org.bd"))
    }
}
