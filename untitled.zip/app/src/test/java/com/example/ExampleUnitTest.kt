package com.example

import com.example.data.AdBlockerEngine
import com.example.data.PortalCategory
import com.example.data.WhitelistRegistry
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun whitelist_allows_govt_bank_newspapers_and_youtube() {
        // Govt & ALL Teletalk wildcard subdomains (*.teletalk.com.bd & *.teletalk.bd)
        assertTrue(WhitelistRegistry.isUrlAllowed("https://alljobs.teletalk.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://dcd.teletalk.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://dcd.teletalk.com.bd/apply.php"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://bogmc.teletalk.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://bogmc.teletalk.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://railway.teletalk.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://dghs.teletalk.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("http://bpsc.teletalk.com.bd/home.php"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://bpsc.gov.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://bangladesh.gov.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://dcd.gov.bd"))

        // Verify custom Teletalk department portal builder
        val dcdPortal = WhitelistRegistry.createCustomTeletalkPortal("dcd")
        assertTrue(dcdPortal != null && dcdPortal.primaryDomain == "dcd.teletalk.com.bd")
        val bogmcBdPortal = WhitelistRegistry.createCustomTeletalkPortal("bogmc.teletalk.bd")
        assertTrue(bogmcBdPortal != null && bogmcBdPortal.primaryDomain == "bogmc.teletalk.bd")

        // Bangladesh Bank e-Recruitment
        assertTrue(WhitelistRegistry.isUrlAllowed("https://erecruitment.bb.org.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.bb.org.bd/en/index.php"))

        // National & International Newspapers
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.prothomalo.com"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://bonikbarta.net"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.thedailystar.net/opinion"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://thefinancialexpress.com.bd"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.bbc.com/bengali"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.reuters.com"))

        // YouTube, Video Lectures & Google Sign-In on YouTube
        assertTrue(WhitelistRegistry.isUrlAllowed("https://m.youtube.com"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://www.youtube.com/watch?v=12345"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://youtu.be/abcde"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://accounts.google.com/ServiceLogin?service=youtube"))
        assertTrue(WhitelistRegistry.isUrlAllowed("https://accounts.youtube.com/accounts/SetSID"))

        // Admit Card Blob & Data URLs
        assertTrue(WhitelistRegistry.isUrlAllowed("blob:https://erecruitment.bb.org.bd/1234-5678"))
        assertTrue(WhitelistRegistry.isUrlAllowed("data:application/pdf;base64,JVBERi0xLjQK"))
    }

    @Test
    fun whitelist_strictly_blocks_external_and_social_sites() {
        assertFalse(WhitelistRegistry.isUrlAllowed("https://www.facebook.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://m.facebook.com/story.php"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://www.instagram.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://www.tiktok.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://twitter.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://x.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://www.netflix.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://www.reddit.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("https://evil-teletalk.com"))
        assertFalse(WhitelistRegistry.isUrlAllowed("javascript:alert(1)"))
    }

    @Test
    fun adblocker_blocks_global_and_bd_ad_networks_while_allowing_content() {
        assertTrue(AdBlockerEngine.isAdOrTrackerRequest("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"))
        assertTrue(AdBlockerEngine.isAdOrTrackerRequest("https://securepubads.g.doubleclick.net/gpt/pubads_impl.js"))
        assertTrue(AdBlockerEngine.isAdOrTrackerRequest("https://dsp.eskimi.com/banner.js"))
        assertTrue(AdBlockerEngine.isAdOrTrackerRequest("https://cdn.taboola.com/libtrc/impl.js"))
        assertTrue(AdBlockerEngine.isAdOrTrackerRequest("https://m.youtube.com/api/stats/ads?adformat=1"))

        assertFalse(AdBlockerEngine.isAdOrTrackerRequest("https://www.prothomalo.com/bangladesh"))
        assertFalse(AdBlockerEngine.isAdOrTrackerRequest("https://erecruitment.bb.org.bd"))
        assertFalse(AdBlockerEngine.isAdOrTrackerRequest("https://m.youtube.com/watch?v=dQw4w9WgXcQ"))
    }

    @Test
    fun registry_contains_all_required_categories_including_youtube() {
        val categories = WhitelistRegistry.portals.map { it.category }.toSet()
        assertTrue(categories.contains(PortalCategory.GOVT_JOBS))
        assertTrue(categories.contains(PortalCategory.BANK_JOBS))
        assertTrue(categories.contains(PortalCategory.VIDEO_LEARNING))
        assertTrue(categories.contains(PortalCategory.NATIONAL_BANGLA))
        assertTrue(categories.contains(PortalCategory.NATIONAL_ENGLISH))
        assertTrue(categories.contains(PortalCategory.INTERNATIONAL_NEWS))
    }
}
